#include "classes.hpp"
#include <windows.h>
#include <cstring>
#include <random>

extern HDC bufferDC;  // Буфер, в который рисуют все объекты

static std::random_device randomDevice;
static std::mt19937       generator(randomDevice());

// ============ РЕАЛИЗАЦИЯ КЛАССА Location ============
// Остается неизменным

Location::Location(int initX, int initY) : x(initX), y(initY) {}
Location::~Location() = default;

int Location::getX() { return x; }
int Location::getY() { return y; }

void Location::setX(int newX) { x = newX; }
void Location::setY(int newY) { y = newY; }

// ============ РЕАЛИЗАЦИЯ АБСТРАКТНОГО КЛАССА AbstractMotorcycle ============
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Содержит общую логику + оставляет специализацию наследникам

AbstractMotorcycle::AbstractMotorcycle(int initX, int initY, int initHealth, MotorcycleCategory cat, int topSpeed, int acceleration, int handling, const char* manufacturer)
    : Location(initX, initY), health(initHealth), visible(true), category(cat), baseTopSpeed(topSpeed), baseAcceleration(acceleration), baseHandling(handling) {
    // Ограничиваем здоровье в диапазоне 10-100
    if (health < 10) health = 10;
    if (health > 100) health = 100;

    // Копируем название производителя
    strncpy_s(manufacturerName, sizeof(manufacturerName), manufacturer, _TRUNCATE);

    updateSpeed();
    updateHitbox();
}

AbstractMotorcycle::~AbstractMotorcycle() = default;

// РЕАЛИЗОВАННЫЕ МЕТОДЫ в абстрактном классе (общая логика для всех мотоциклов)

int                AbstractMotorcycle::getHealth() { return health; }
int                AbstractMotorcycle::getSpeed() { return speed; }
Hitbox             AbstractMotorcycle::getHitbox() { return hitbox; }
MotorcycleCategory AbstractMotorcycle::getCategory() { return category; }
const char*        AbstractMotorcycle::getManufacturer() { return manufacturerName; }

void AbstractMotorcycle::takeDamage(int damage) {
    // ОБЩАЯ ЛОГИКА получения урона для всех мотоциклов
    health -= damage;
    if (health < 10) health = 10;  // Минимальное здоровье 10
    updateSpeed();                 // Обновляем скорость после получения урона
}

void AbstractMotorcycle::repair() {
    // ОБЩАЯ ЛОГИКА ремонта для всех мотоциклов
    health = 100;   // Полное восстановление здоровья
    updateSpeed();  // Обновляем скорость после ремонта
}

void AbstractMotorcycle::updateSpeed() {
    // ОБЩАЯ ЛОГИКА расчета скорости для всех мотоциклов
    speed = health / 10;  // Скорость в пикселях = здоровье/10
}

void AbstractMotorcycle::updateHitbox() {
    // ОБЩАЯ ЛОГИКА хитбокса для всех мотоциклов
    hitbox.left   = x - 40;
    hitbox.right  = x + 40;
    hitbox.top    = y - 30;
    hitbox.bottom = y + 30;
}

bool AbstractMotorcycle::isVisible() {
    // ОБЩАЯ ЛОГИКА видимости (может быть переопределена в наследниках)
    return visible;
}

// ОБЩАЯ ЛОГИКА движения для всех мотоциклов (с автоматическими эффектами)
void AbstractMotorcycle::moveTo(int newX, int newY) {
    // Показываем эффект движения в старой позиции
    showMovementEffect(x, y);  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип создает свои эффекты

    hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип скрывает себя по-своему
    x = newX;
    y = newY;
    updateHitbox();
    show();  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип показывает себя по-своему

    // Через короткое время скрываем эффект
    Sleep(30);
    hideMovementEffect(x, y);  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип убирает свои эффекты
}

void AbstractMotorcycle::moveUp(int screenHeight) {
    int newY = y - speed;
    if (newY >= 30) {
        moveTo(x, newY);
    }
}

void AbstractMotorcycle::moveDown(int screenHeight) {
    int newY = y + speed;
    if (newY <= screenHeight - 30) {
        moveTo(x, newY);
    }
}

void AbstractMotorcycle::moveLeft(int screenWidth) {
    int newX = x - speed;
    if (newX >= 40) {
        moveTo(newX, y);
    }
}

void AbstractMotorcycle::moveRight(int screenWidth) {
    int newX = x + speed;
    if (newX <= screenWidth - 40) {
        moveTo(newX, y);
    }
}

// РЕАЛИЗАЦИЯ интерфейса IPerformanceRated в абстрактном классе
// ОБЩАЯ ЛОГИКА: характеристики зависят от здоровья и базовых значений
int AbstractMotorcycle::getTopSpeed() {
    // Максимальная скорость снижается при низком здоровье
    return baseTopSpeed * health / 100;
}

int AbstractMotorcycle::getAcceleration() {
    // Ускорение снижается при низком здоровье
    return baseAcceleration * health / 100;
}

int AbstractMotorcycle::getHandling() {
    // Управляемость снижается при низком здоровье
    return baseHandling * health / 100;
}

// ============ РЕАЛИЗАЦИЯ АБСТРАКТНОГО КЛАССА AbstractRoadHazard ============
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Общая логика опасностей + специализация в наследниках

AbstractRoadHazard::AbstractRoadHazard(int initX, int initY, int minDmg, int maxDmg, int radius)
    : Location(initX, initY), visible(true), minDamage(minDmg), maxDamage(maxDmg), impactRadius(radius), isActive(true) {
    updateHitbox();
}

AbstractRoadHazard::~AbstractRoadHazard() = default;

// РЕАЛИЗОВАННЫЕ МЕТОДЫ в абстрактном классе (общая логика для всех опасностей)

Hitbox AbstractRoadHazard::getHitbox() { return hitbox; }

void AbstractRoadHazard::updateHitbox() {
    // ОБЩАЯ ЛОГИКА хитбокса для всех опасностей на дороге
    hitbox.left   = x - 20;
    hitbox.right  = x + 20;
    hitbox.top    = y - 15;
    hitbox.bottom = y + 15;
}

int AbstractRoadHazard::getRandomDamage() {
    // ОБЩАЯ ЛОГИКА генерации случайного урона в заданном диапазоне
    std::uniform_int_distribution<> damageRange(minDamage, maxDamage);
    return damageRange(generator);
}

bool AbstractRoadHazard::getIsActive() { return isActive; }
void AbstractRoadHazard::setActive(bool active) { isActive = active; }

bool AbstractRoadHazard::isVisible() {
    return visible;
}

void AbstractRoadHazard::respawn(int screenWidth, int screenHeight) {
    // ОБЩАЯ ЛОГИКА респавна для всех опасностей
    constexpr int padding = 50;

    std::uniform_int_distribution<> distX(padding, screenWidth - padding);
    std::uniform_int_distribution<> distY(padding, screenHeight - padding);

    const int newX = distX(generator);
    const int newY = distY(generator);

    hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип опасности стирает себя по-своему
    x = newX;
    y = newY;
    updateHitbox();
    isActive = true;  // Активируем опасность после респавна
    show();           // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип опасности рисует себя по-своему
}

void AbstractRoadHazard::applyEffect(AbstractMotorcycle* motorcycle) {
    // ОБЩАЯ ЛОГИКА применения урона к мотоциклу
    if (motorcycle && isActive) {
        int damage = getRandomDamage();
        motorcycle->takeDamage(damage);
        isActive = false;  // Деактивируем опасность после использования
    }
}

bool AbstractRoadHazard::canInteract() {
    return isActive && visible;
}

int AbstractRoadHazard::getEffectStrength() {
    // ОБЩАЯ ЛОГИКА: сила эффекта = среднее значение урона
    return (minDamage + maxDamage) / 2;
}

// ============ РЕАЛИЗАЦИЯ АБСТРАКТНОГО КЛАССА AbstractBenefit ============
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Общая логика пользы + специализация в наследниках

AbstractBenefit::AbstractBenefit(int initX, int initY, int healAmt, int cooldown)
    : Location(initX, initY), visible(true), healAmount(healAmt), cooldownTime(cooldown), currentCooldown(0), isAvailable(true) {
    updateHitbox();
}

AbstractBenefit::~AbstractBenefit() = default;

// РЕАЛИЗОВАННЫЕ МЕТОДЫ в абстрактном классе (общая логика для всех полезных объектов)

Hitbox AbstractBenefit::getHitbox() { return hitbox; }

void AbstractBenefit::updateHitbox() {
    // ОБЩАЯ ЛОГИКА хитбокса для всех полезных объектов
    hitbox.left   = x - 20;
    hitbox.right  = x + 20;
    hitbox.top    = y - 15;
    hitbox.bottom = y + 15;
}

int  AbstractBenefit::getHealAmount() { return healAmount; }
bool AbstractBenefit::getIsAvailable() { return isAvailable; }

void AbstractBenefit::startCooldown() {
    // ОБЩАЯ ЛОГИКА запуска перезарядки
    isAvailable     = false;
    currentCooldown = cooldownTime;
}

void AbstractBenefit::updateCooldown() {
    // ОБЩАЯ ЛОГИКА обновления перезарядки
    if (currentCooldown > 0) {
        currentCooldown--;
        if (currentCooldown == 0) {
            isAvailable = true;
        }
    }
}

bool AbstractBenefit::isVisible() {
    return visible;
}

void AbstractBenefit::respawn(int screenWidth, int screenHeight) {
    // ОБЩАЯ ЛОГИКА респавна для всех полезных объектов
    constexpr int padding = 50;

    std::uniform_int_distribution<> distX(padding, screenWidth - padding);
    std::uniform_int_distribution<> distY(padding, screenHeight - padding);

    const int newX = distX(generator);
    const int newY = distY(generator);

    hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ
    x = newX;
    y = newY;
    updateHitbox();
    isAvailable     = true;  // Делаем доступным после респавна
    currentCooldown = 0;
    show();  // ПОЛИМОРФНЫЙ ВЫЗОВ
}

void AbstractBenefit::applyEffect(AbstractMotorcycle* motorcycle) {
    // ОБЩАЯ ЛОГИКА применения пользы к мотоциклу
    if (motorcycle && isAvailable) {
        motorcycle->repair();  // Полное восстановление здоровья
        startCooldown();       // Запускаем перезарядку
    }
}

bool AbstractBenefit::canInteract() {
    return isAvailable && visible;
}

int AbstractBenefit::getEffectStrength() {
    // ОБЩАЯ ЛОГИКА: сила эффекта = количество исцеления
    return healAmount;
}

// ============ РЕАЛИЗАЦИЯ АБСТРАКТНОГО КЛАССА AbstractTransformer ============
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Общая логика трансформации + специализация направления

AbstractTransformer::AbstractTransformer(int initX, int initY, int power, int charge)
    : Location(initX, initY), visible(true), transformPower(power), isCharged(true), chargeTime(charge), currentCharge(charge) {
    updateHitbox();
}

AbstractTransformer::~AbstractTransformer() = default;

// РЕАЛИЗОВАННЫЕ МЕТОДЫ в абстрактном классе (общая логика для всех трансформеров)

Hitbox AbstractTransformer::getHitbox() { return hitbox; }

void AbstractTransformer::updateHitbox() {
    // ОБЩАЯ ЛОГИКА хитбокса для всех трансформеров
    hitbox.left   = x - 20;
    hitbox.right  = x + 20;
    hitbox.top    = y - 15;
    hitbox.bottom = y + 15;
}

int  AbstractTransformer::getTransformPower() { return transformPower; }
bool AbstractTransformer::getIsCharged() { return isCharged; }

void AbstractTransformer::discharge() {
    // ОБЩАЯ ЛОГИКА разрядки трансформера
    isCharged     = false;
    currentCharge = 0;
}

void AbstractTransformer::recharge() {
    // ОБЩАЯ ЛОГИКА перезарядки трансформера
    isCharged     = true;
    currentCharge = chargeTime;
}

void AbstractTransformer::updateCharge() {
    // ОБЩАЯ ЛОГИКА обновления зарядки
    if (!isCharged && currentCharge < chargeTime) {
        currentCharge++;
        if (currentCharge >= chargeTime) {
            isCharged = true;
        }
    }
}

bool AbstractTransformer::isVisible() {
    return visible;
}

void AbstractTransformer::respawn(int screenWidth, int screenHeight) {
    // ОБЩАЯ ЛОГИКА респавна для всех трансформеров с полной перезарядкой
    constexpr int padding = 50;

    std::uniform_int_distribution<> distX(padding, screenWidth - padding);
    std::uniform_int_distribution<> distY(padding, screenHeight - padding);

    const int newX = distX(generator);
    const int newY = distY(generator);

    hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ
    x = newX;
    y = newY;
    updateHitbox();
    recharge();  // Полная перезарядка после респавна
    show();      // ПОЛИМОРФНЫЙ ВЫЗОВ
}

bool AbstractTransformer::canInteract() {
    return isCharged && visible;
}

int AbstractTransformer::getEffectStrength() {
    // ОБЩАЯ ЛОГИКА: сила эффекта = сила трансформации
    return transformPower;
}

// ============ РЕАЛИЗАЦИЯ КОНКРЕТНЫХ МОТОЦИКЛОВ ============
// Наследники AbstractMotorcycle - реализуют только уникальные особенности

SportBike::SportBike(int initX, int initY)
    : AbstractMotorcycle(initX, initY, 100, MotorcycleCategory::SPORT, 200, 95, 90, "Yamaha") {}

void SportBike::show() {
    visible = true;

    // УНИКАЛЬНАЯ ОТРИСОВКА спортбайка (та же, что в предыдущих заданиях)
    HPEN   pen      = CreatePen(PS_SOLID, 3, RGB(200, 0, 0));
    HBRUSH brush    = CreateSolidBrush(RGB(220, 0, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Ellipse(bufferDC, x - 30, y - 15, x + 30, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // Колеса
    pen      = CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
    brush    = CreateSolidBrush(RGB(80, 80, 80));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Ellipse(bufferDC, x + 15, y - 10, x + 35, y + 10);
    Ellipse(bufferDC, x - 35, y - 10, x - 15, y + 10);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // Руль и сиденье
    pen    = CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    MoveToEx(bufferDC, x + 20, y - 20, NULL);
    LineTo(bufferDC, x + 30, y - 25);
    MoveToEx(bufferDC, x + 10, y - 20, NULL);
    LineTo(bufferDC, x + 20, y - 25);

    brush    = CreateSolidBrush(RGB(0, 0, 0));
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);
    Rectangle(bufferDC, x - 20, y - 8, x + 5, y - 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // Спортивные полосы
    pen    = CreatePen(PS_SOLID, 1, RGB(255, 255, 0));
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    MoveToEx(bufferDC, x - 25, y - 5, NULL);
    LineTo(bufferDC, x + 25, y - 5);
    MoveToEx(bufferDC, x - 25, y + 5, NULL);
    LineTo(bufferDC, x + 25, y + 5);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void SportBike::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 40, y - 30, x + 40, y + 30);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// УНИКАЛЬНЫЕ ЗВУКИ SportBike
const char* SportBike::getEngineSound() {
    return "VROOOM! High-performance racing engine at maximum RPM!";
}

const char* SportBike::getHornSound() {
    return "Beep-beep! Quick sporty electronic racing horn!";
}

// УНИКАЛЬНОЕ ОПИСАНИЕ SportBike
const char* SportBike::getTypeName() {
    return "SportBike";
}

const char* SportBike::getDescription() {
    return "Ultra-fast Yamaha racing machine engineered for track dominance and speed records.";
}

int SportBike::getEffectStrength() {
    return 90;  // Высокая интенсивность эффектов
}

// УНИКАЛЬНЫЕ ЭФФЕКТЫ SportBike
void SportBike::showMovementEffect(int effectX, int effectY) {
    HPEN pen    = CreatePen(PS_SOLID, 1, RGB(255, 150, 0));
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    for (int i = 0; i < 8; i++) {
        int sparkX = effectX - 50 - (i * 5);
        int sparkY = effectY + (rand() % 20 - 10);

        MoveToEx(bufferDC, sparkX, sparkY, NULL);
        LineTo(bufferDC, sparkX - 8, sparkY + (rand() % 6 - 3));
    }

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void SportBike::hideMovementEffect(int effectX, int effectY) {
    HPEN pen    = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    Rectangle(bufferDC, effectX - 100, effectY - 20, effectX - 40, effectY + 20);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

// ============ Остальные конкретные классы реализуются аналогично ============
// Для краткости показываю только ключевые различия

Cruiser::Cruiser(int initX, int initY)
    : AbstractMotorcycle(initX, initY, 100, MotorcycleCategory::TOURING, 150, 70, 75, "Harley-Davidson") {}

void Cruiser::show() {
    visible = true;
    // Уникальная отрисовка круизера (черный, массивный)
    HPEN   pen      = CreatePen(PS_SOLID, 4, RGB(20, 20, 20));
    HBRUSH brush    = CreateSolidBrush(RGB(40, 40, 40));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 35, y - 12, x + 35, y + 12);

    // ... остальная отрисовка круизера

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

void Cruiser::hide() {
    visible         = false;
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 50, y - 45, x + 45, y + 25);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

const char* Cruiser::getEngineSound() {
    return "GRUMBLE-GRUMBLE! Deep Harley V-twin rumble echoing for miles!";
}

const char* Cruiser::getHornSound() {
    return "HOOOONK! Powerful touring horn with deep bass resonance!";
}

const char* Cruiser::getTypeName() {
    return "Cruiser";
}

const char* Cruiser::getDescription() {
    return "Iconic Harley-Davidson cruiser built for comfort and long-distance highway touring.";
}

int Cruiser::getEffectStrength() {
    return 70;  // Средняя интенсивность эффектов
}

void Cruiser::showMovementEffect(int effectX, int effectY) {
    // Дым от мощного двигателя
    HPEN pen    = CreatePen(PS_SOLID, 2, RGB(120, 120, 120));
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    for (int i = 0; i < 5; i++) {
        int smokeX = effectX - 40 - (i * 8);
        int smokeY = effectY + (i % 2 == 0 ? -5 : 5);

        Ellipse(bufferDC, smokeX - 6, smokeY - 4, smokeX + 6, smokeY + 4);
    }

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void Cruiser::hideMovementEffect(int effectX, int effectY) {
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, effectX - 80, effectY - 15, effectX - 30, effectY + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

DirtBike::DirtBike(int initX, int initY)
    : AbstractMotorcycle(initX, initY, 100, MotorcycleCategory::OFFROAD, 120, 85, 95, "KTM") {}

void DirtBike::show() {
    visible = true;
    // Уникальная отрисовка эндуро (оранжевый, с защитой)
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(255, 140, 0));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 165, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Ellipse(bufferDC, x - 25, y - 10, x + 25, y + 10);

    // ... остальная отрисовка эндуро

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

void DirtBike::hide() {
    visible         = false;
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 40, y - 35, x + 40, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

const char* DirtBike::getEngineSound() {
    return "BRRAP-BRRAP! Sharp KTM single-cylinder engine ready for off-road adventure!";
}

const char* DirtBike::getHornSound() {
    return "Pip-pip! High-pitched off-road alert system!";
}

const char* DirtBike::getTypeName() {
    return "DirtBike";
}

const char* DirtBike::getDescription() {
    return "Rugged KTM off-road machine designed to conquer any terrain and extreme conditions.";
}

int DirtBike::getEffectStrength() {
    std::uniform_int_distribution<> intensity(50, 95);
    return intensity(generator);  // Переменная интенсивность в зависимости от "местности"
}

void DirtBike::showMovementEffect(int effectX, int effectY) {
    // Пыль и камни от бездорожья
    HPEN pen    = CreatePen(PS_SOLID, 1, RGB(160, 130, 90));
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    for (int i = 0; i < 12; i++) {
        int dustX = effectX - 35 - (rand() % 20);
        int dustY = effectY + (rand() % 30 - 15);

        SetPixel(bufferDC, dustX, dustY, RGB(160, 130, 90));
        SetPixel(bufferDC, dustX + 1, dustY, RGB(140, 110, 70));

        if (i % 3 == 0) {
            Rectangle(bufferDC, dustX - 1, dustY - 1, dustX + 2, dustY + 2);
        }
    }

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void DirtBike::hideMovementEffect(int effectX, int effectY) {
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, effectX - 60, effectY - 20, effectX - 25, effectY + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ РЕАЛИЗАЦИЯ КОНКРЕТНЫХ ОПАСНОСТЕЙ ============

Rock::Rock(int initX, int initY) : AbstractRoadHazard(initX, initY, 5, 15, 25) {}

void Rock::show() {
    visible = true;

    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(100, 100, 100));
    HBRUSH brush    = CreateSolidBrush(RGB(120, 120, 120));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    POINT points[6] = {
        {x - 18, y + 10}, {x - 5, y - 12}, {x + 8, y - 15}, {x + 20, y - 5}, {x + 15, y + 12}, {x - 10, y + 15}};
    Polygon(bufferDC, points, 6);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

void Rock::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

const char* Rock::getTypeName() {
    return "Sharp Rock";
}

const char* Rock::getDescription() {
    return "Dangerous granite boulder that can damage wheels and suspension systems.";
}

Pothole::Pothole(int initX, int initY) : AbstractRoadHazard(initX, initY, 10, 25, 30) {}

void Pothole::show() {
    visible = true;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(80, 50, 20));
    HBRUSH brush    = CreateSolidBrush(RGB(60, 40, 20));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Ellipse(bufferDC, x - 20, y - 10, x + 20, y + 10);

    HBRUSH shadowBrush = CreateSolidBrush(RGB(40, 25, 10));
    SelectObject(bufferDC, shadowBrush);
    Ellipse(bufferDC, x - 15, y - 8, x + 15, y + 8);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(shadowBrush);
}

void Pothole::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 15, x + 25, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

const char* Pothole::getTypeName() {
    return "Deep Pothole";
}

const char* Pothole::getDescription() {
    return "Severe asphalt crater that can cause major undercarriage and suspension damage.";
}

// ============ РЕАЛИЗАЦИЯ КОНКРЕТНЫХ ПОЛЕЗНЫХ ОБЪЕКТОВ ============

Service::Service(int initX, int initY) : AbstractBenefit(initX, initY, 100, 300) {}

void Service::show() {
    visible = true;

    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(0, 150, 0));
    HBRUSH brush    = CreateSolidBrush(RGB(0, 200, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 20, y - 15, x + 20, y + 15);

    HPEN   crossPen   = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    HBRUSH crossBrush = CreateSolidBrush(RGB(255, 255, 255));
    SelectObject(bufferDC, crossPen);
    SelectObject(bufferDC, crossBrush);

    Rectangle(bufferDC, x - 12, y - 3, x + 12, y + 3);
    Rectangle(bufferDC, x - 3, y - 12, x + 3, y + 12);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(crossPen);
    DeleteObject(crossBrush);
}

void Service::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

const char* Service::getTypeName() {
    return "Professional Service Station";
}

const char* Service::getDescription() {
    return "Expert motorcycle repair facility that completely restores vehicle condition.";
}

// ============ РЕАЛИЗАЦИЯ КОНКРЕТНЫХ ТРАНСФОРМЕРОВ ============

ClockwiseTransformer::ClockwiseTransformer(int initX, int initY)
    : AbstractTransformer(initX, initY, 80, 200) {}

void ClockwiseTransformer::show() {
    visible = true;

    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(0, 0, 200));
    HBRUSH brush    = CreateSolidBrush(RGB(100, 100, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Ellipse(bufferDC, x - 20, y - 15, x + 20, y + 15);

    HPEN arrowPen = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    SelectObject(bufferDC, arrowPen);

    MoveToEx(bufferDC, x - 10, y - 8, NULL);
    LineTo(bufferDC, x + 8, y - 8);
    LineTo(bufferDC, x + 8, y + 8);

    MoveToEx(bufferDC, x + 8, y + 8, NULL);
    LineTo(bufferDC, x + 3, y + 3);
    MoveToEx(bufferDC, x + 8, y + 8, NULL);
    LineTo(bufferDC, x + 13, y + 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(arrowPen);
}

void ClockwiseTransformer::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

const char* ClockwiseTransformer::getTypeName() {
    return "Clockwise Transformer";
}

const char* ClockwiseTransformer::getDescription() {
    return "Mystical device that transforms motorcycles following the clockwise sequence pattern.";
}

void ClockwiseTransformer::applyEffect(AbstractMotorcycle* motorcycle) {
    // УНИКАЛЬНАЯ ЛОГИКА трансформации по часовой стрелке
    if (motorcycle && isCharged) {
        // Здесь была бы логика определения следующего типа по часовой стрелке
        // В реальной реализации это потребовало бы знания о конкретных типах
        discharge();  // Разряжаем трансформер после использования
    }
}

CounterClockwiseTransformer::CounterClockwiseTransformer(int initX, int initY)
    : AbstractTransformer(initX, initY, 80, 200) {}

void CounterClockwiseTransformer::show() {
    visible = true;

    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(128, 0, 128));
    HBRUSH brush    = CreateSolidBrush(RGB(200, 100, 200));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Ellipse(bufferDC, x - 20, y - 15, x + 20, y + 15);

    HPEN arrowPen = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    SelectObject(bufferDC, arrowPen);

    MoveToEx(bufferDC, x + 10, y - 8, NULL);
    LineTo(bufferDC, x - 8, y - 8);
    LineTo(bufferDC, x - 8, y + 8);

    MoveToEx(bufferDC, x - 8, y + 8, NULL);
    LineTo(bufferDC, x - 3, y + 3);
    MoveToEx(bufferDC, x - 8, y + 8, NULL);
    LineTo(bufferDC, x - 13, y + 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(arrowPen);
}

void CounterClockwiseTransformer::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

const char* CounterClockwiseTransformer::getTypeName() {
    return "Counter-Clockwise Transformer";
}

const char* CounterClockwiseTransformer::getDescription() {
    return "Mystical device that transforms motorcycles in reverse sequence pattern.";
}

void CounterClockwiseTransformer::applyEffect(AbstractMotorcycle* motorcycle) {
    // УНИКАЛЬНАЯ ЛОГИКА трансформации против часовой стрелки
    if (motorcycle && isCharged) {
        // Здесь была бы логика определения следующего типа против часовой стрелки
        discharge();  // Разряжаем трансформер после использования
    }
}
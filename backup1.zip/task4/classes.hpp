#pragma once
#include <random>

// Структура хитбокса для определения коллизий
struct Hitbox {
    int left;    // Левая граница хитбокса
    int right;   // Правая граница хитбокса
    int top;     // Верхняя граница хитбокса
    int bottom;  // Нижняя граница хитбокса
};

// Перечисление типов мотоциклов для лучшей типизации
enum class MotorcycleCategory {
    SPORT,    // Спортивная категория
    TOURING,  // Туристическая категория
    OFFROAD   // Внедорожная категория
};

// Перечисление типов воздействия объектов дороги
enum class EffectType {
    DAMAGE,    // Наносит урон
    HEAL,      // Восстанавливает здоровье
    TRANSFORM  // Изменяет тип мотоцикла
};

// =====================================================================
// ИНТЕРФЕЙСЫ (остаются из предыдущего задания)
// =====================================================================

class IDisplayable {
   public:
    virtual ~IDisplayable()  = default;
    virtual void show()      = 0;
    virtual void hide()      = 0;
    virtual bool isVisible() = 0;
};

class IMovable {
   public:
    virtual ~IMovable()                     = default;
    virtual void moveUp(int screenHeight)   = 0;
    virtual void moveDown(int screenHeight) = 0;
    virtual void moveLeft(int screenWidth)  = 0;
    virtual void moveRight(int screenWidth) = 0;
    virtual void moveTo(int newX, int newY) = 0;
};

class IRespawnable {
   public:
    virtual ~IRespawnable()                                 = default;
    virtual void respawn(int screenWidth, int screenHeight) = 0;
};

class ISoundEmitter {
   public:
    virtual ~ISoundEmitter()             = default;
    virtual const char* getEngineSound() = 0;
    virtual const char* getHornSound()   = 0;
};

class IDescriptive {
   public:
    virtual ~IDescriptive()                 = default;
    virtual const char* getTypeName()       = 0;
    virtual const char* getDescription()    = 0;
    virtual int         getEffectStrength() = 0;
};

class IEffectGenerator {
   public:
    virtual ~IEffectGenerator()                   = default;
    virtual void showMovementEffect(int x, int y) = 0;
    virtual void hideMovementEffect(int x, int y) = 0;
};

// =====================================================================
// НОВЫЕ ИНТЕРФЕЙСЫ ДЛЯ ЗАДАНИЯ 4
// =====================================================================

// Интерфейс для объектов, которые имеют характеристики производительности
class IPerformanceRated {
   public:
    virtual ~IPerformanceRated()  = default;
    virtual int getTopSpeed()     = 0;  // Максимальная скорость
    virtual int getAcceleration() = 0;  // Ускорение
    virtual int getHandling()     = 0;  // Управляемость
};

// Интерфейс для объектов, которые могут взаимодействовать с мотоциклами
class IInteractive {
   public:
    virtual ~IInteractive()                                        = default;
    virtual void applyEffect(class AbstractMotorcycle* motorcycle) = 0;  // Применить эффект к мотоциклу
    virtual bool canInteract()                                     = 0;  // Можно ли взаимодействовать
};

// =====================================================================
// БАЗОВЫЕ КЛАССЫ
// =====================================================================

// Базовый класс для хранения координат (остается неизменным)
class Location {
   protected:
    int x;  // Координата X объекта
    int y;  // Координата Y объекта

   public:
    Location(int initX, int initY);
    virtual ~Location();

    int getX();
    int getY();

    void setX(int newX);
    void setY(int newY);
};

// =====================================================================
// АБСТРАКТНЫЕ КЛАССЫ (НОВЫЕ ДЛЯ ЗАДАНИЯ 4)
// =====================================================================

// АБСТРАКТНЫЙ КЛАСС 1: AbstractMotorcycle
// Объединяет общую функциональность всех мотоциклов и группирует интерфейсы
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Содержит как реализованные методы, так и чисто виртуальные
class AbstractMotorcycle : public Location, public IDisplayable, public IMovable, public ISoundEmitter, public IDescriptive, public IEffectGenerator, public IPerformanceRated {
   protected:
    // ДАННЫЕ АБСТРАКТНОГО КЛАССА (общие для всех мотоциклов)
    int                health;                // Здоровье мотоцикла (10-100)
    int                speed;                 // Текущая скорость в пикселях за шаг
    bool               visible;               // Флаг видимости объекта
    Hitbox             hitbox;                // Хитбокс для определения коллизий
    MotorcycleCategory category;              // Категория мотоцикла
    int                baseTopSpeed;          // Базовая максимальная скорость
    int                baseAcceleration;      // Базовое ускорение
    int                baseHandling;          // Базовая управляемость
    char               manufacturerName[50];  // Название производителя

   public:
    AbstractMotorcycle(int initX, int initY, int initHealth, MotorcycleCategory cat, int topSpeed, int acceleration, int handling, const char* manufacturer);
    virtual ~AbstractMotorcycle();

    // РЕАЛИЗОВАННЫЕ МЕТОДЫ (общая логика для всех мотоциклов)
    int                getHealth();
    int                getSpeed();
    Hitbox             getHitbox();
    MotorcycleCategory getCategory();
    const char*        getManufacturer();

    // Методы управления состоянием (реализованы в абстрактном классе)
    void takeDamage(int damage);  // Получение урона
    void repair();                // Полное восстановление здоровья
    void updateSpeed();           // Обновление скорости на основе здоровья
    void updateHitbox();          // Обновление хитбокса

    // ЧАСТИЧНО РЕАЛИЗОВАННЫЕ МЕТОДЫ (базовая логика + возможность переопределения)
    virtual bool isVisible() override;  // Базовая реализация, может быть переопределена

    // РЕАЛИЗОВАННЫЕ методы движения с общей логикой
    virtual void moveUp(int screenHeight) override;
    virtual void moveDown(int screenHeight) override;
    virtual void moveLeft(int screenWidth) override;
    virtual void moveRight(int screenWidth) override;
    virtual void moveTo(int newX, int newY) override;

    // Реализация интерфейса IPerformanceRated (общая логика с учетом здоровья)
    virtual int getTopSpeed() override;      // Реализован: зависит от здоровья и базовой скорости
    virtual int getAcceleration() override;  // Реализован: зависит от здоровья и базового ускорения
    virtual int getHandling() override;      // Реализован: зависит от здоровья и базовой управляемости

    // ЧИСТО ВИРТУАЛЬНЫЕ МЕТОДЫ (должны быть реализованы в наследниках)
    // Эти методы делают класс абстрактным

    // Интерфейс IDisplayable - каждый тип мотоцикла рисует себя по-своему
    virtual void show() override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальная отрисовка
    virtual void hide() override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальное стирание

    // Интерфейс ISoundEmitter - каждый тип издает свои звуки
    virtual const char* getEngineSound() override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальный звук двигателя
    virtual const char* getHornSound() override   = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальный звук сигнала

    // Интерфейс IDescriptive - каждый тип описывает себя по-своему
    virtual const char* getTypeName() override       = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальное название
    virtual const char* getDescription() override    = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальное описание
    virtual int         getEffectStrength() override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальная сила эффектов

    // Интерфейс IEffectGenerator - каждый тип создает свои эффекты
    virtual void showMovementEffect(int x, int y) override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальные эффекты
    virtual void hideMovementEffect(int x, int y) override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальное стирание эффектов
};

// АБСТРАКТНЫЙ КЛАСС 2: AbstractRoadHazard
// Представляет опасности на дороге (камни, ямы и т.д.)
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Содержит общую логику опасностей + чисто виртуальные методы специализации
class AbstractRoadHazard : public Location, public IDisplayable, public IRespawnable, public IDescriptive, public IInteractive {
   protected:
    // ДАННЫЕ АБСТРАКТНОГО КЛАССА
    bool   visible;       // Флаг видимости
    Hitbox hitbox;        // Хитбокс для коллизий
    int    minDamage;     // Минимальный урон
    int    maxDamage;     // Максимальный урон
    int    impactRadius;  // Радиус воздействия
    bool   isActive;      // Активна ли опасность

   public:
    AbstractRoadHazard(int initX, int initY, int minDmg, int maxDmg, int radius);
    virtual ~AbstractRoadHazard();

    // РЕАЛИЗОВАННЫЕ МЕТОДЫ (общая логика для всех опасностей)
    Hitbox getHitbox();
    void   updateHitbox();
    int    getRandomDamage();  // Генерирует случайный урон в диапазоне
    bool   getIsActive();
    void   setActive(bool active);

    // Реализация интерфейса IDisplayable
    virtual bool isVisible() override;

    // Реализация интерфейса IRespawnable (общая логика респавна)
    virtual void respawn(int screenWidth, int screenHeight) override;

    // Реализация интерфейса IInteractive (общая логика применения урона)
    virtual void applyEffect(AbstractMotorcycle* motorcycle) override;  // Наносит урон мотоциклу
    virtual bool canInteract() override;                                // Проверяет активность

    // ЧАСТИЧНО РЕАЛИЗОВАННЫЕ МЕТОДЫ
    virtual int getEffectStrength() override;  // Базовая реализация на основе среднего урона

    // ЧИСТО ВИРТУАЛЬНЫЕ МЕТОДЫ (специализация в наследниках)
    virtual void        show() override           = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальная отрисовка опасности
    virtual void        hide() override           = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальное стирание
    virtual const char* getTypeName() override    = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - название опасности
    virtual const char* getDescription() override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - описание опасности
};

// АБСТРАКТНЫЙ КЛАСС 3: AbstractBenefit
// Представляет полезные объекты на дороге (сервисы, бонусы и т.д.)
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Содержит общую логику пользы + чисто виртуальные методы специализации
class AbstractBenefit : public Location, public IDisplayable, public IRespawnable, public IDescriptive, public IInteractive {
   protected:
    // ДАННЫЕ АБСТРАКТНОГО КЛАССА
    bool   visible;          // Флаг видимости
    Hitbox hitbox;           // Хитбокс для коллизий
    int    healAmount;       // Количество восстанавливаемого здоровья
    int    cooldownTime;     // Время перезарядки (в кадрах)
    int    currentCooldown;  // Текущее время до перезарядки
    bool   isAvailable;      // Доступен ли для использования

   public:
    AbstractBenefit(int initX, int initY, int healAmt, int cooldown);
    virtual ~AbstractBenefit();

    // РЕАЛИЗОВАННЫЕ МЕТОДЫ (общая логика для всех полезных объектов)
    Hitbox getHitbox();
    void   updateHitbox();
    int    getHealAmount();
    bool   getIsAvailable();
    void   startCooldown();   // Запускает перезарядку
    void   updateCooldown();  // Обновляет состояние перезарядки

    // Реализация интерфейса IDisplayable
    virtual bool isVisible() override;

    // Реализация интерфейса IRespawnable (общая логика респавна)
    virtual void respawn(int screenWidth, int screenHeight) override;

    // Реализация интерфейса IInteractive (общая логика восстановления)
    virtual void applyEffect(AbstractMotorcycle* motorcycle) override;  // Восстанавливает здоровье
    virtual bool canInteract() override;                                // Проверяет доступность

    // ЧАСТИЧНО РЕАЛИЗОВАННЫЕ МЕТОДЫ
    virtual int getEffectStrength() override;  // Базовая реализация на основе исцеления

    // ЧИСТО ВИРТУАЛЬНЫЕ МЕТОДЫ (специализация в наследниках)
    virtual void        show() override           = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальная отрисовка пользы
    virtual void        hide() override           = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальное стирание
    virtual const char* getTypeName() override    = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - название пользы
    virtual const char* getDescription() override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - описание пользы
};

// АБСТРАКТНЫЙ КЛАСС 4: AbstractTransformer
// Представляет трансформирующие объекты (меняют тип мотоцикла)
// КЛЮЧЕВАЯ ОСОБЕННОСТЬ: Содержит общую логику трансформации + чисто виртуальные методы направления
class AbstractTransformer : public Location, public IDisplayable, public IRespawnable, public IDescriptive, public IInteractive {
   protected:
    // ДАННЫЕ АБСТРАКТНОГО КЛАССА
    bool   visible;         // Флаг видимости
    Hitbox hitbox;          // Хитбокс для коллизий
    int    transformPower;  // Сила трансформации
    bool   isCharged;       // Заряжен ли трансформер
    int    chargeTime;      // Время зарядки
    int    currentCharge;   // Текущий заряд

   public:
    AbstractTransformer(int initX, int initY, int power, int charge);
    virtual ~AbstractTransformer();

    // РЕАЛИЗОВАННЫЕ МЕТОДЫ (общая логика для всех трансформеров)
    Hitbox getHitbox();
    void   updateHitbox();
    int    getTransformPower();
    bool   getIsCharged();
    void   discharge();     // Разряжает трансформер
    void   recharge();      // Перезаряжает трансформер
    void   updateCharge();  // Обновляет состояние зарядки

    // Реализация интерфейса IDisplayable
    virtual bool isVisible() override;

    // Реализация интерфейса IRespawnable (общая логика респавна с перезарядкой)
    virtual void respawn(int screenWidth, int screenHeight) override;

    // Реализация интерфейса IInteractive (базовая проверка зарядки)
    virtual bool canInteract() override;  // Проверяет заряженность

    // ЧАСТИЧНО РЕАЛИЗОВАННЫЕ МЕТОДЫ
    virtual int getEffectStrength() override;  // Базовая реализация на основе силы трансформации

    // ЧИСТО ВИРТУАЛЬНЫЕ МЕТОДЫ (специализация направления трансформации)
    virtual void        show() override                                      = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальная отрисовка трансформера
    virtual void        hide() override                                      = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - уникальное стирание
    virtual const char* getTypeName() override                               = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - название трансформера
    virtual const char* getDescription() override                            = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - описание трансформации
    virtual void        applyEffect(AbstractMotorcycle* motorcycle) override = 0;  // ЧИСТО ВИРТУАЛЬНЫЙ - логика трансформации
};

// =====================================================================
// КОНКРЕТНЫЕ КЛАССЫ - НАСЛЕДНИКИ АБСТРАКТНЫХ КЛАССОВ
// =====================================================================

// Конкретные мотоциклы - наследники AbstractMotorcycle
class SportBike : public AbstractMotorcycle {
   public:
    SportBike(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getEngineSound() override;
    virtual const char* getHornSound() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
    virtual int         getEffectStrength() override;
    virtual void        showMovementEffect(int x, int y) override;
    virtual void        hideMovementEffect(int x, int y) override;
};

class Cruiser : public AbstractMotorcycle {
   public:
    Cruiser(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getEngineSound() override;
    virtual const char* getHornSound() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
    virtual int         getEffectStrength() override;
    virtual void        showMovementEffect(int x, int y) override;
    virtual void        hideMovementEffect(int x, int y) override;
};

class DirtBike : public AbstractMotorcycle {
   public:
    DirtBike(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getEngineSound() override;
    virtual const char* getHornSound() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
    virtual int         getEffectStrength() override;
    virtual void        showMovementEffect(int x, int y) override;
    virtual void        hideMovementEffect(int x, int y) override;
};

// Конкретные опасности - наследники AbstractRoadHazard
class Rock : public AbstractRoadHazard {
   public:
    Rock(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
};

class Pothole : public AbstractRoadHazard {
   public:
    Pothole(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
};

// Конкретные полезные объекты - наследники AbstractBenefit
class Service : public AbstractBenefit {
   public:
    Service(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
};

// Конкретные трансформеры - наследники AbstractTransformer
class ClockwiseTransformer : public AbstractTransformer {
   public:
    ClockwiseTransformer(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
    virtual void        applyEffect(AbstractMotorcycle* motorcycle) override;  // Трансформация по часовой стрелке
};

class CounterClockwiseTransformer : public AbstractTransformer {
   public:
    CounterClockwiseTransformer(int initX, int initY);

    // Реализация всех чисто виртуальных методов абстрактного класса
    virtual void        show() override;
    virtual void        hide() override;
    virtual const char* getTypeName() override;
    virtual const char* getDescription() override;
    virtual void        applyEffect(AbstractMotorcycle* motorcycle) override;  // Трансформация против часовой стрелки
};
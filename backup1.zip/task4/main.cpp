/************************************************************
 *      ЗАДАНИЕ 4: НАСЛЕДОВАНИЕ ОТ АБСТРАКТНЫХ КЛАССОВ     *
 *----------------------------------------------------------*
 * Project Type  : Win64 Console Application                *
 * Project Name  : task4_abstract_classes                   *
 * File Name     : main.cpp                                 *
 * Language      : CPP, MSVC 2022                           *
 * Programmer    : Student                                  *
 * Created       : 30.06.2025                               *
 * Last Revision : 30.06.2025                               *
 * Comment(s)    : Демонстрация абстрактных классов -       *
 *                 объединение интерфейсов с данными и      *
 *                 частичной реализацией. Показывает        *
 *                 эволюцию от интерфейсов к полной         *
 *                 объектно-ориентированной архитектуре     *
 ************************************************************/

#include <windows.h>
#include <random>
#include "classes.hpp"

#define KEY_DOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define _UNICODE

HWND hwnd;      // Глобальный дескриптор окна
HDC  bufferDC;  // Глобальный HDC, используемый при отрисовке

// Генератор случайных чисел для main.cpp
static std::random_device mainRandomDevice;
static std::mt19937       mainGenerator(mainRandomDevice());

// Индексы типов мотоциклов для матриц переходов
enum MotorcycleTypeIndex {
    SPORTBIKE_INDEX = 0,
    CRUISER_INDEX   = 1,
    DIRTBIKE_INDEX  = 2,
    MOTORCYCLE_TYPE_COUNT
};

// =====================================================================
// ГЛОБАЛЬНЫЕ ОБЪЕКТЫ - ДЕМОНСТРАЦИЯ АБСТРАКТНЫХ КЛАССОВ
// =====================================================================

// Конкретные мотоциклы (наследники AbstractMotorcycle)
SportBike sportbike(400, 300);
Cruiser   cruiser(400, 300);
DirtBike  dirtbike(400, 300);

// Конкретные опасности (наследники AbstractRoadHazard)
Rock    rock(150, 150);
Pothole pothole(650, 450);

// Конкретные полезные объекты (наследники AbstractBenefit)
Service service(400, 150);

// Конкретные трансформеры (наследники AbstractTransformer)
ClockwiseTransformer        clockwiseTransformer(200, 450);
CounterClockwiseTransformer counterClockwiseTransformer(600, 150);

// =====================================================================
// ПОЛИМОРФНЫЕ МАССИВЫ ЧЕРЕЗ АБСТРАКТНЫЕ КЛАССЫ
// КЛЮЧЕВАЯ ДЕМОНСТРАЦИЯ: Работа через указатели на абстрактные классы
// =====================================================================

// Массив указателей на АБСТРАКТНЫЙ КЛАСС AbstractMotorcycle
// Все мотоциклы имеют общую базовую функциональность + уникальные особенности
AbstractMotorcycle* abstractMotorcycles[MOTORCYCLE_TYPE_COUNT] = {
    &sportbike, &cruiser, &dirtbike};

// Массив указателей на АБСТРАКТНЫЙ КЛАСС AbstractRoadHazard
// Все опасности имеют общую логику урона + уникальную отрисовку
AbstractRoadHazard* abstractHazards[] = {&rock, &pothole};
const int           HAZARD_COUNT      = sizeof(abstractHazards) / sizeof(abstractHazards[0]);

// Массив указателей на АБСТРАКТНЫЙ КЛАСС AbstractBenefit
// Все полезные объекты имеют общую логику исцеления + уникальную отрисовку
AbstractBenefit* abstractBenefits[] = {&service};
const int        BENEFIT_COUNT      = sizeof(abstractBenefits) / sizeof(abstractBenefits[0]);

// Массив указателей на АБСТРАКТНЫЙ КЛАСС AbstractTransformer
// Все трансформеры имеют общую логику зарядки + уникальную трансформацию
AbstractTransformer* abstractTransformers[] = {&clockwiseTransformer, &counterClockwiseTransformer};
const int            TRANSFORMER_COUNT      = sizeof(abstractTransformers) / sizeof(abstractTransformers[0]);

// Массив указателей на ИНТЕРФЕЙС IInteractive (все интерактивные объекты)
// Демонстрирует работу с интерфейсами поверх абстрактных классов
IInteractive* interactiveObjects[] = {
    &rock, &pothole, &service, &clockwiseTransformer, &counterClockwiseTransformer};
const int INTERACTIVE_COUNT = sizeof(interactiveObjects) / sizeof(interactiveObjects[0]);

// Массив указателей на ИНТЕРФЕЙС IDisplayable (все визуальные объекты)
IDisplayable* displayableObjects[] = {
    &sportbike, &cruiser, &dirtbike, &rock, &pothole, &service,
    &clockwiseTransformer, &counterClockwiseTransformer};
const int DISPLAYABLE_COUNT = sizeof(displayableObjects) / sizeof(displayableObjects[0]);

// Матрицы переходов для трансформеров
const MotorcycleTypeIndex clockwiseTransitions[MOTORCYCLE_TYPE_COUNT] = {
    CRUISER_INDEX,   // SportBike -> Cruiser
    DIRTBIKE_INDEX,  // Cruiser -> DirtBike
    SPORTBIKE_INDEX  // DirtBike -> SportBike
};

const MotorcycleTypeIndex counterClockwiseTransitions[MOTORCYCLE_TYPE_COUNT] = {
    DIRTBIKE_INDEX,   // SportBike -> DirtBike
    SPORTBIKE_INDEX,  // Cruiser -> SportBike
    CRUISER_INDEX     // DirtBike -> Cruiser
};

// Текущий активный мотоцикл
MotorcycleTypeIndex activeMotorcycleIndex = SPORTBIKE_INDEX;
AbstractMotorcycle* activeMotorcyclePtr   = abstractMotorcycles[activeMotorcycleIndex];

// =====================================================================
// ДЕМОНСТРАЦИОННЫЕ ФУНКЦИИ АБСТРАКТНЫХ КЛАССОВ
// =====================================================================

// ФУНКЦИЯ 1: Демонстрация общих свойств абстрактных мотоциклов
void DemonstrateAbstractMotorcycleFeatures() {
    // КЛЮЧЕВАЯ ДЕМОНСТРАЦИЯ: Общие методы работают одинаково для всех мотоциклов
    // через указатели на абстрактный класс

    for (int i = 0; i < MOTORCYCLE_TYPE_COUNT; i++) {
        AbstractMotorcycle* bike = abstractMotorcycles[i];

        // Получаем общие характеристики через абстрактный класс
        int                health       = bike->getHealth();        // Общий метод из AbstractMotorcycle
        int                topSpeed     = bike->getTopSpeed();      // Реализован в AbstractMotorcycle
        int                acceleration = bike->getAcceleration();  // Реализован в AbstractMotorcycle
        int                handling     = bike->getHandling();      // Реализован в AbstractMotorcycle
        MotorcycleCategory category     = bike->getCategory();      // Общий метод из AbstractMotorcycle
        const char*        manufacturer = bike->getManufacturer();  // Общий метод из AbstractMotorcycle

        // Получаем уникальные характеристики через полиморфизм
        const char* typeName    = bike->getTypeName();     // ПОЛИМОРФНЫЙ - каждый тип реализует по-своему
        const char* engineSound = bike->getEngineSound();  // ПОЛИМОРФНЫЙ - каждый тип звучит по-своему

        // Демонстрируется, как АБСТРАКТНЫЙ КЛАСС объединяет общую логику с полиморфизмом
    }
}

// ФУНКЦИЯ 2: Демонстрация взаимодействия через абстрактные классы
void DemonstrateAbstractInteractions() {
    // ДЕМОНСТРАЦИЯ: Как абстрактные классы упрощают взаимодействие объектов

    AbstractMotorcycle* currentBike = activeMotorcyclePtr;

    // Проверяем взаимодействие со всеми опасностями через AbstractRoadHazard
    for (int i = 0; i < HAZARD_COUNT; i++) {
        AbstractRoadHazard* hazard = abstractHazards[i];

        if (hazard->canInteract()) {  // Общий метод из AbstractRoadHazard
            // hazard->applyEffect(currentBike);  // Общий метод применения урона
            // Каждая опасность наносит урон по общему алгоритму, но с разными параметрами
        }
    }

    // Проверяем взаимодействие с полезными объектами через AbstractBenefit
    for (int i = 0; i < BENEFIT_COUNT; i++) {
        AbstractBenefit* benefit = abstractBenefits[i];

        if (benefit->canInteract()) {  // Общий метод из AbstractBenefit
            // benefit->applyEffect(currentBike);  // Общий метод восстановления здоровья
        }
    }

    // Проверяем взаимодействие с трансформерами через AbstractTransformer
    for (int i = 0; i < TRANSFORMER_COUNT; i++) {
        AbstractTransformer* transformer = abstractTransformers[i];

        if (transformer->canInteract()) {  // Общий метод из AbstractTransformer
            // transformer->applyEffect(currentBike);  // Полиморфный метод трансформации
        }
    }
}

// ФУНКЦИЯ 3: Демонстрация полиморфного респавна через абстрактные классы
void RespawnAllAbstractObjects() {
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // ДЕМОНСТРАЦИЯ: Респавн через абстрактные классы с общей логикой

    // Респавн всех опасностей через AbstractRoadHazard
    for (int i = 0; i < HAZARD_COUNT; i++) {
        abstractHazards[i]->respawn(width, height);  // Общий метод из AbstractRoadHazard
    }

    // Респавн всех полезных объектов через AbstractBenefit
    for (int i = 0; i < BENEFIT_COUNT; i++) {
        abstractBenefits[i]->respawn(width, height);  // Общий метод из AbstractBenefit
    }

    // Респавн всех трансформеров через AbstractTransformer
    for (int i = 0; i < TRANSFORMER_COUNT; i++) {
        abstractTransformers[i]->respawn(width, height);  // Общий метод из AbstractTransformer
    }
}

// ФУНКЦИЯ 4: Демонстрация обновления состояний через абстрактные классы
void UpdateAllAbstractObjects() {
    // ДЕМОНСТРАЦИЯ: Как абстрактные классы обеспечивают единообразное обновление состояний

    // Обновляем состояние всех полезных объектов (cooldown)
    for (int i = 0; i < BENEFIT_COUNT; i++) {
        abstractBenefits[i]->updateCooldown();  // Общий метод из AbstractBenefit
    }

    // Обновляем состояние всех трансформеров (charge)
    for (int i = 0; i < TRANSFORMER_COUNT; i++) {
        abstractTransformers[i]->updateCharge();  // Общий метод из AbstractTransformer
    }
}

// Функция проверки коллизий с демонстрацией работы абстрактных классов
bool isCollisionAbstract(AbstractMotorcycle* motorcycle, IDisplayable* object) {
    if (!motorcycle || !object) return false;
    if (!motorcycle->isVisible() || !object->isVisible()) return false;

    Hitbox motorcycleHitbox = motorcycle->getHitbox();  // Общий метод из AbstractMotorcycle

    // Для получения хитбокса объекта нужно привести к конкретному абстрактному классу
    // Это демонстрирует иерархию абстракций
    AbstractRoadHazard* hazard = dynamic_cast<AbstractRoadHazard*>(object);
    if (hazard) {
        Hitbox objectHitbox = hazard->getHitbox();  // Общий метод из AbstractRoadHazard
        return (objectHitbox.left <= motorcycleHitbox.right &&
                objectHitbox.right >= motorcycleHitbox.left &&
                objectHitbox.top <= motorcycleHitbox.bottom &&
                objectHitbox.bottom >= motorcycleHitbox.top);
    }

    AbstractBenefit* benefit = dynamic_cast<AbstractBenefit*>(object);
    if (benefit) {
        Hitbox objectHitbox = benefit->getHitbox();  // Общий метод из AbstractBenefit
        return (objectHitbox.left <= motorcycleHitbox.right &&
                objectHitbox.right >= motorcycleHitbox.left &&
                objectHitbox.top <= motorcycleHitbox.bottom &&
                objectHitbox.bottom >= motorcycleHitbox.top);
    }

    AbstractTransformer* transformer = dynamic_cast<AbstractTransformer*>(object);
    if (transformer) {
        Hitbox objectHitbox = transformer->getHitbox();  // Общий метод из AbstractTransformer
        return (objectHitbox.left <= motorcycleHitbox.right &&
                objectHitbox.right >= motorcycleHitbox.left &&
                objectHitbox.top <= motorcycleHitbox.bottom &&
                objectHitbox.bottom >= motorcycleHitbox.top);
    }

    return false;
}

// Функция изменения активного мотоцикла через абстрактные классы
void ChangeActiveMotorcycleAbstract(MotorcycleTypeIndex newIndex) {
    // ДЕМОНСТРАЦИЯ: Работа с абстрактными классами при смене объектов

    // Получаем данные от текущего мотоцикла через AbstractMotorcycle
    int x      = activeMotorcyclePtr->getX();       // Общий метод из Location (наследуется)
    int y      = activeMotorcyclePtr->getY();       // Общий метод из Location (наследуется)
    int health = activeMotorcyclePtr->getHealth();  // Общий метод из AbstractMotorcycle

    // Скрываем текущий мотоцикл через полиморфизм
    activeMotorcyclePtr->hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип скрывает себя по-своему

    // Обновляем активный мотоцикл
    activeMotorcycleIndex = newIndex;
    activeMotorcyclePtr   = abstractMotorcycles[activeMotorcycleIndex];

    // Синхронизируем здоровье через общие методы AbstractMotorcycle
    while (activeMotorcyclePtr->getHealth() > health) {
        activeMotorcyclePtr->takeDamage(1);  // Общий метод из AbstractMotorcycle
    }
    if (activeMotorcyclePtr->getHealth() < health) {
        activeMotorcyclePtr->repair();  // Общий метод из AbstractMotorcycle
        while (activeMotorcyclePtr->getHealth() > health) {
            activeMotorcyclePtr->takeDamage(1);  // Общий метод из AbstractMotorcycle
        }
    }

    // Перемещаем и показываем новый мотоцикл через абстрактный класс
    activeMotorcyclePtr->moveTo(x, y);  // Общий метод из AbstractMotorcycle (с эффектами!)
    activeMotorcyclePtr->show();        // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип рисует себя по-своему
}

// Функция проверки коллизий с демонстрацией интерфейса IInteractive
void CheckAbstractCollisions() {
    bool collision = false;
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // КЛЮЧЕВАЯ ДЕМОНСТРАЦИЯ: Взаимодействие через интерфейс IInteractive
    // поверх абстрактных классов

    for (int i = 0; i < INTERACTIVE_COUNT; i++) {
        IInteractive* interactive = interactiveObjects[i];
        IDisplayable* displayable = dynamic_cast<IDisplayable*>(interactive);

        if (displayable && isCollisionAbstract(activeMotorcyclePtr, displayable)) {
            collision = true;

            // Применяем эффект через интерфейс IInteractive
            if (interactive->canInteract()) {
                interactive->applyEffect(activeMotorcyclePtr);  // ПОЛИМОРФНЫЙ ВЫЗОВ!

                // Респавним объект через соответствующий абстрактный класс
                IRespawnable* respawnable = dynamic_cast<IRespawnable*>(interactive);
                if (respawnable) {
                    respawnable->respawn(width, height);  // ПОЛИМОРФНЫЙ ВЫЗОВ!
                }
            }
        }
    }

    // Специальная обработка трансформеров (требует смены типа мотоцикла)
    if (isCollisionAbstract(activeMotorcyclePtr, &clockwiseTransformer)) {
        if (clockwiseTransformer.canInteract()) {
            collision                    = true;
            MotorcycleTypeIndex newIndex = clockwiseTransitions[activeMotorcycleIndex];
            ChangeActiveMotorcycleAbstract(newIndex);
            clockwiseTransformer.respawn(width, height);
        }
    }

    if (isCollisionAbstract(activeMotorcyclePtr, &counterClockwiseTransformer)) {
        if (counterClockwiseTransformer.canInteract()) {
            collision                    = true;
            MotorcycleTypeIndex newIndex = counterClockwiseTransitions[activeMotorcycleIndex];
            ChangeActiveMotorcycleAbstract(newIndex);
            counterClockwiseTransformer.respawn(width, height);
        }
    }

    if (collision) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Функция обработки ввода с демонстрацией абстрактных классов
void CheckKeyboardInputAbstract() {
    bool needRedraw = false;
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // ДЕМОНСТРАЦИЯ: Движение через методы абстрактного класса AbstractMotorcycle
    // Общая логика движения + полиморфные эффекты

    if (KEY_DOWN('W') || KEY_DOWN('w') || KEY_DOWN(VK_UP)) {
        activeMotorcyclePtr->moveUp(height);  // Общий метод из AbstractMotorcycle
        needRedraw = true;
    }
    if (KEY_DOWN('S') || KEY_DOWN('s') || KEY_DOWN(VK_DOWN)) {
        activeMotorcyclePtr->moveDown(height);  // Общий метод из AbstractMotorcycle
        needRedraw = true;
    }
    if (KEY_DOWN('A') || KEY_DOWN('a') || KEY_DOWN(VK_LEFT)) {
        activeMotorcyclePtr->moveLeft(width);  // Общий метод из AbstractMotorcycle
        needRedraw = true;
    }
    if (KEY_DOWN('D') || KEY_DOWN('d') || KEY_DOWN(VK_RIGHT)) {
        activeMotorcyclePtr->moveRight(width);  // Общий метод из AbstractMotorcycle
        needRedraw = true;
    }

    // Дополнительные демонстрации абстрактных классов
    if (KEY_DOWN('R') || KEY_DOWN('r')) {
        RespawnAllAbstractObjects();  // Респавн через абстрактные классы
        needRedraw = true;
    }

    if (KEY_DOWN('H') || KEY_DOWN('h')) {
        // Полиморфное скрытие/показ через интерфейс IDisplayable
        static bool hidden = false;
        hidden             = !hidden;
        for (int i = 0; i < DISPLAYABLE_COUNT; i++) {
            if (hidden) {
                displayableObjects[i]->hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ!
            } else {
                displayableObjects[i]->show();  // ПОЛИМОРФНЫЙ ВЫЗОВ!
            }
        }
        needRedraw = true;
    }

    // Автоматическое обновление состояний объектов
    UpdateAllAbstractObjects();
    DemonstrateAbstractMotorcycleFeatures();
    DemonstrateAbstractInteractions();

    CheckAbstractCollisions();
    if (needRedraw) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Обработчик сообщений окна
LRESULT CALLBACK WndProc(HWND hwnd, const UINT msg, const WPARAM wParam, const LPARAM lParam) {
    PAINTSTRUCT ps;

    switch (msg) {
        case WM_PAINT: {
            HDC hdcLocal = BeginPaint(hwnd, &ps);

            RECT rect;
            GetClientRect(hwnd, &rect);
            const int width  = rect.right - rect.left;
            const int height = rect.bottom - rect.top;

            HDC     memDC     = CreateCompatibleDC(hdcLocal);
            HBITMAP memBitmap = CreateCompatibleBitmap(hdcLocal, width, height);
            HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, memBitmap);

            HBRUSH bgBrush  = CreateSolidBrush(RGB(200, 200, 200));
            HBRUSH oldBrush = (HBRUSH)SelectObject(memDC, bgBrush);
            FillRect(memDC, &rect, bgBrush);
            SelectObject(memDC, oldBrush);
            DeleteObject(bgBrush);

            bufferDC = memDC;

            // ДЕМОНСТРАЦИЯ: Отображение через абстрактные классы и интерфейсы

            // Показываем активный мотоцикл через абстрактный класс
            activeMotorcyclePtr->show();  // ПОЛИМОРФНЫЙ ВЫЗОВ через AbstractMotorcycle*

            // Показываем все остальные объекты через интерфейс IDisplayable
            for (int i = 3; i < DISPLAYABLE_COUNT; i++) {  // Пропускаем мотоциклы (первые 3)
                displayableObjects[i]->show();             // ПОЛИМОРФНЫЙ ВЫЗОВ через IDisplayable*
            }

            // Отображаем расширенную информацию о мотоцикле через абстрактный класс
            SetBkMode(memDC, TRANSPARENT);
            SetTextColor(memDC, RGB(0, 0, 0));

            char info[600];

            // ДЕМОНСТРАЦИЯ: Получение информации через абстрактный класс и полиморфизм
            const char* typeName     = activeMotorcyclePtr->getTypeName();      // ПОЛИМОРФНЫЙ
            const char* manufacturer = activeMotorcyclePtr->getManufacturer();  // Общий метод
            int         health       = activeMotorcyclePtr->getHealth();        // Общий метод
            int         topSpeed     = activeMotorcyclePtr->getTopSpeed();      // Общий метод (зависит от здоровья)
            int         acceleration = activeMotorcyclePtr->getAcceleration();  // Общий метод (зависит от здоровья)
            int         handling     = activeMotorcyclePtr->getHandling();      // Общий метод (зависит от здоровья)

            const char* categoryName = "";
            switch (activeMotorcyclePtr->getCategory()) {  // Общий метод из AbstractMotorcycle
                case MotorcycleCategory::SPORT: categoryName = "Sport"; break;
                case MotorcycleCategory::TOURING: categoryName = "Touring"; break;
                case MotorcycleCategory::OFFROAD: categoryName = "Off-Road"; break;
            }

            wsprintfA(info, "TASK 4: ABSTRACT CLASSES | %s %s (%s) | Health: %d%%",
                      manufacturer, typeName, categoryName, health);
            TextOutA(memDC, 10, 10, info, lstrlenA(info));

            wsprintfA(info, "Performance: Speed=%d | Acceleration=%d | Handling=%d",
                      topSpeed, acceleration, handling);
            TextOutA(memDC, 10, 30, info, lstrlenA(info));

            const char* description = activeMotorcyclePtr->getDescription();  // ПОЛИМОРФНЫЙ
            const char* engineSound = activeMotorcyclePtr->getEngineSound();  // ПОЛИМОРФНЫЙ

            wsprintfA(info, "Description: %s", description);
            TextOutA(memDC, 10, 50, info, lstrlenA(info));

            wsprintfA(info, "Engine: %s", engineSound);
            TextOutA(memDC, 10, 70, info, lstrlenA(info));

            wsprintfA(info, "Controls: WASD/Arrows=Move | R=Respawn All | H=Hide/Show All");
            TextOutA(memDC, 10, 90, info, lstrlenA(info));

            wsprintfA(info, "Architecture: Abstract classes provide common data + partial implementation + polymorphism");
            TextOutA(memDC, 10, 110, info, lstrlenA(info));

            BitBlt(hdcLocal, 0, 0, width, height, memDC, 0, 0, SRCCOPY);

            SelectObject(memDC, oldBitmap);
            DeleteObject(memBitmap);
            DeleteDC(memDC);

            EndPaint(hwnd, &ps);
        } break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// Точка входа в приложение
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
    // Регистрация класса окна
    WNDCLASSEX wc    = {0};
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "task4_abstract_classes";
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Ошибка регистрации окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    hwnd = CreateWindowEx(
        0,
        "task4_abstract_classes",
        "Задание 4: Наследование от абстрактных классов - Полная ООП архитектура",
        WS_OVERLAPPEDWINDOW | WS_MAXIMIZE,
        CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT,
        nullptr, nullptr, hInstance, nullptr);

    if (hwnd == NULL) {
        MessageBox(NULL, "Ошибка создания окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    nShowCmd = SW_MAXIMIZE;
    ShowWindow(hwnd, nShowCmd);
    UpdateWindow(hwnd);

    // Инициализация объектов
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Создаем новые экземпляры с использованием абстрактных классов
    sportbike = SportBike(width / 2, height / 2);
    cruiser   = Cruiser(width / 2, height / 2);
    dirtbike  = DirtBike(width / 2, height / 2);

    // Респавн всех объектов через абстрактные классы
    RespawnAllAbstractObjects();

    // Переинициализация массивов указателей на абстрактные классы
    abstractMotorcycles[0] = &sportbike;
    abstractMotorcycles[1] = &cruiser;
    abstractMotorcycles[2] = &dirtbike;

    // Обновляем массивы для демонстрации полиморфизма
    displayableObjects[0] = &sportbike;
    displayableObjects[1] = &cruiser;
    displayableObjects[2] = &dirtbike;

    // Случайный выбор начального типа мотоцикла
    std::uniform_int_distribution<> typeRange(0, MOTORCYCLE_TYPE_COUNT - 1);
    activeMotorcycleIndex = static_cast<MotorcycleTypeIndex>(typeRange(mainGenerator));
    activeMotorcyclePtr   = abstractMotorcycles[activeMotorcycleIndex];

    // Скрываем все мотоциклы через абстрактные указатели, показываем только активный
    for (int i = 0; i < MOTORCYCLE_TYPE_COUNT; i++) {
        abstractMotorcycles[i]->hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ через AbstractMotorcycle*
    }

    activeMotorcyclePtr->show();  // ПОЛИМОРФНЫЙ ВЫЗОВ - показываем выбранный мотоцикл

    InvalidateRect(hwnd, NULL, FALSE);

    // Основной цикл с демонстрацией абстрактных классов
    MSG msg;
    while (true) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) {
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        } else {
            CheckKeyboardInputAbstract();  // Проверяем ввод через абстрактные классы
            Sleep(16);                     // ~60 FPS
        }
    }

    return (int)msg.wParam;
}
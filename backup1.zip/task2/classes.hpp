#pragma once
#include <random>

// Структура хитбокса для определения коллизий
struct Hitbox {
    int left;    // Левая граница хитбокса
    int right;   // Правая граница хитбокса
    int top;     // Верхняя граница хитбокса
    int bottom;  // Нижняя граница хитбокса
};

// =====================================================================
// ИНТЕРФЕЙСЫ (чисто виртуальные классы без полей данных)
// =====================================================================

// Интерфейс для объектов, которые могут отображаться на экране
// Этот интерфейс определяет базовые операции видимости
class IDisplayable {
   public:
    virtual ~IDisplayable()  = default;  // Виртуальный деструктор для корректного полиморфизма
    virtual void show()      = 0;        // Чисто виртуальный метод для отображения объекта
    virtual void hide()      = 0;        // Чисто виртуальный метод для скрытия объекта
    virtual bool isVisible() = 0;        // Чисто виртуальный метод для проверки видимости
};

// Интерфейс для движущихся объектов
// Этот интерфейс выделен из базового класса Vehicle для демонстрации наследования от интерфейса
class IMovable {
   public:
    virtual ~IMovable()                     = default;  // Виртуальный деструктор
    virtual void moveUp(int screenHeight)   = 0;        // Чисто виртуальный метод движения вверх
    virtual void moveDown(int screenHeight) = 0;        // Чисто виртуальный метод движения вниз
    virtual void moveLeft(int screenWidth)  = 0;        // Чисто виртуальный метод движения влево
    virtual void moveRight(int screenWidth) = 0;        // Чисто виртуальный метод движения вправо
    virtual void moveTo(int newX, int newY) = 0;        // Чисто виртуальный метод перемещения в точку
};

// Интерфейс для объектов, которые могут респавниться (появляться в новых местах)
// Этот интерфейс выделен из базового класса RoadObject для демонстрации наследования от интерфейса
class IRespawnable {
   public:
    virtual ~IRespawnable()                                 = default;  // Виртуальный деструктор
    virtual void respawn(int screenWidth, int screenHeight) = 0;        // Чисто виртуальный метод респавна
};

// =====================================================================
// БАЗОВЫЕ КЛАССЫ С ДАННЫМИ И ОБЩЕЙ ФУНКЦИОНАЛЬНОСТЬЮ
// =====================================================================

// Базовый класс для хранения координат (переиспользуем из исходного кода)
class Location {
   protected:
    int x;  // Координата X объекта
    int y;  // Координата Y объекта

   public:
    Location(int initX, int initY);  // Конструктор с инициализацией координат
    virtual ~Location();             // Виртуальный деструктор

    int getX();  // Получение координаты X
    int getY();  // Получение координаты Y

    void setX(int newX);  // Установка новой координаты X
    void setY(int newY);  // Установка новой координаты Y
};

// Базовый класс для всех транспортных средств
// ВАЖНО: Теперь наследует от интерфейсов IDisplayable и IMovable
// Методы движения удалены из этого класса и будут реализованы через интерфейс IMovable
class Vehicle : public Location, public IDisplayable, public IMovable {
   protected:
    int    health;   // Здоровье мотоцикла (10-100)
    int    speed;    // Скорость в пикселях за шаг (health/10)
    bool   visible;  // Флаг видимости объекта
    Hitbox hitbox;   // Хитбокс для определения коллизий

   public:
    Vehicle(int initX, int initY, int initHealth);  // Конструктор с координатами и здоровьем
    virtual ~Vehicle();                             // Виртуальный деструктор

    // Геттеры для общих свойств
    int    getHealth();
    int    getSpeed();
    Hitbox getHitbox();

    // Управление здоровьем и скоростью
    void takeDamage(int damage);  // Получение урона (не меньше 10 здоровья)
    void repair();                // Полное восстановление здоровья
    void updateSpeed();           // Обновление скорости на основе здоровья
    void updateHitbox();          // Обновление хитбокса на основе текущих координат

    // Реализация интерфейса IDisplayable
    virtual bool isVisible() override;  // Переопределение метода проверки видимости

    // Реализация интерфейса IMovable
    // Эти методы были УДАЛЕНЫ из первоначального класса Vehicle и теперь реализуются через интерфейс
    virtual void moveUp(int screenHeight) override;    // Реализация движения вверх через интерфейс
    virtual void moveDown(int screenHeight) override;  // Реализация движения вниз через интерфейс
    virtual void moveLeft(int screenWidth) override;   // Реализация движения влево через интерфейс
    virtual void moveRight(int screenWidth) override;  // Реализация движения вправо через интерфейс
    virtual void moveTo(int newX, int newY) override;  // Реализация перемещения через интерфейс

    // Базовые методы отображения (будут переопределены в наследниках)
    virtual void show() override;  // Реализация отображения через интерфейс IDisplayable
    virtual void hide() override;  // Реализация скрытия через интерфейс IDisplayable
};

// Спортивный мотоцикл - быстрый и маневренный
class SportBike : public Vehicle {
   public:
    SportBike(int initX, int initY);  // Конструктор

    // Переопределенные методы отрисовки для уникального внешнего вида
    virtual void show() override;  // Отображение спортбайка на экране
    virtual void hide() override;  // Скрытие спортбайка с экрана
};

// Круизер - мощный и устойчивый мотоцикл
class Cruiser : public Vehicle {
   public:
    Cruiser(int initX, int initY);  // Конструктор

    // Переопределенные методы отрисовки для уникального внешнего вида
    virtual void show() override;  // Отображение круизера на экране
    virtual void hide() override;  // Скрытие круизера с экрана
};

// Эндуро мотоцикл - проходимый и легкий
class DirtBike : public Vehicle {
   public:
    DirtBike(int initX, int initY);  // Конструктор

    // Переопределенные методы отрисовки для уникального внешнего вида
    virtual void show() override;  // Отображение эндуро на экране
    virtual void hide() override;  // Скрытие эндуро с экрана
};

// Базовый класс для всех объектов на дороге
// ВАЖНО: Теперь наследует от интерфейсов IDisplayable и IRespawnable
// Метод respawn удален из этого класса и будет реализован через интерфейс IRespawnable
class RoadObject : public Location, public IDisplayable, public IRespawnable {
   protected:
    bool   visible;  // Флаг видимости объекта
    Hitbox hitbox;   // Хитбокс для определения коллизий

   public:
    RoadObject(int initX, int initY);  // Конструктор
    virtual ~RoadObject();             // Виртуальный деструктор

    Hitbox getHitbox();     // Получение хитбокса
    void   updateHitbox();  // Обновление хитбокса

    // Реализация интерфейса IDisplayable
    virtual bool isVisible() override;  // Переопределение метода проверки видимости

    // Реализация интерфейса IRespawnable
    // Этот метод был УДАЛЕН из первоначального класса RoadObject и теперь реализуется через интерфейс
    virtual void respawn(int screenWidth, int screenHeight) override;  // Реализация респавна через интерфейс

    // Методы отображения остаются чисто виртуальными (будут переопределены в наследниках)
    virtual void show() override = 0;  // Чисто виртуальный метод отображения
    virtual void hide() override = 0;  // Чисто виртуальный метод скрытия
};

// Камень - наносит случайный урон от 5 до 15
class Rock : public RoadObject {
   public:
    Rock(int initX, int initY);  // Конструктор

    virtual void show() override;  // Отображение камня
    virtual void hide() override;  // Скрытие камня

    int getDamage();  // Получение случайного урона от камня
};

// Яма - наносит случайный урон от 10 до 25
class Pothole : public RoadObject {
   public:
    Pothole(int initX, int initY);  // Конструктор

    virtual void show() override;  // Отображение ямы
    virtual void hide() override;  // Скрытие ямы

    int getDamage();  // Получение случайного урона от ямы
};

// Сервис - полностью восстанавливает здоровье мотоцикла
class Service : public RoadObject {
   public:
    Service(int initX, int initY);  // Конструктор

    virtual void show() override;  // Отображение сервиса
    virtual void hide() override;  // Скрытие сервиса
};

// Трансформер 1 - меняет тип мотоцикла по часовой стрелке
class Transformer1 : public RoadObject {
   public:
    Transformer1(int initX, int initY);  // Конструктор

    virtual void show() override;  // Отображение трансформера
    virtual void hide() override;  // Скрытие трансформера
};

// Трансформер 2 - меняет тип мотоцикла против часовой стрелки
class Transformer2 : public RoadObject {
   public:
    Transformer2(int initX, int initY);  // Конструктор

    virtual void show() override;  // Отображение трансформера
    virtual void hide() override;  // Скрытие трансформера
};
#include "classes.hpp"
#include <windows.h>
#include <random>

extern HDC bufferDC;  // Буфер, в который рисуют все объекты

static std::random_device randomDevice;
static std::mt19937       generator(randomDevice());

// ============ РЕАЛИЗАЦИЯ КЛАССА Location ============
// Этот класс остается без изменений, так как он не участвует в интерфейсах

Location::Location(int initX, int initY) : x(initX), y(initY) {}
Location::~Location() = default;

int Location::getX() { return x; }
int Location::getY() { return y; }

void Location::setX(int newX) { x = newX; }
void Location::setY(int newY) { y = newY; }

// ============ РЕАЛИЗАЦИЯ КЛАССА Vehicle ============
// ВАЖНЫЕ ИЗМЕНЕНИЯ: Теперь Vehicle наследует от интерфейсов IDisplayable и IMovable
// Все методы движения теперь реализуются через интерфейс IMovable с ключевым словом override

Vehicle::Vehicle(int initX, int initY, int initHealth)
    : Location(initX, initY), health(initHealth), visible(true) {
    // Ограничиваем здоровье в диапазоне 10-100
    if (health < 10) health = 10;
    if (health > 100) health = 100;

    updateSpeed();   // Вычисляем скорость на основе здоровья
    updateHitbox();  // Инициализируем хитбокс
}

Vehicle::~Vehicle() = default;

int    Vehicle::getHealth() { return health; }
int    Vehicle::getSpeed() { return speed; }
Hitbox Vehicle::getHitbox() { return hitbox; }

void Vehicle::takeDamage(int damage) {
    health -= damage;
    if (health < 10) health = 10;  // Минимальное здоровье 10
    updateSpeed();                 // Обновляем скорость после получения урона
}

void Vehicle::repair() {
    health = 100;   // Полное восстановление здоровья
    updateSpeed();  // Обновляем скорость после ремонта
}

void Vehicle::updateSpeed() {
    speed = health / 10;  // Скорость в пикселях = здоровье/10
}

void Vehicle::updateHitbox() {
    // Мотоцикл имеет размер 80x60 пикселей (в 2 раза больше объектов)
    hitbox.left   = x - 40;
    hitbox.right  = x + 40;
    hitbox.top    = y - 30;
    hitbox.bottom = y + 30;
}

// ============ РЕАЛИЗАЦИЯ ИНТЕРФЕЙСА IDisplayable В КЛАССЕ Vehicle ============

bool Vehicle::isVisible() {
    // Реализация метода интерфейса IDisplayable
    return visible;
}

void Vehicle::show() {
    // Базовая реализация интерфейса IDisplayable - будет переопределена в наследниках
    visible = true;
}

void Vehicle::hide() {
    // Базовая реализация интерфейса IDisplayable - будет переопределена в наследниках
    visible = false;
}

// ============ РЕАЛИЗАЦИЯ ИНТЕРФЕЙСА IMovable В КЛАССЕ Vehicle ============
// Эти методы были УДАЛЕНЫ из первого задания и теперь возвращены через интерфейс

void Vehicle::moveTo(int newX, int newY) {
    // Реализация чисто виртуального метода интерфейса IMovable
    hide();
    x = newX;
    y = newY;
    updateHitbox();  // Обновляем хитбокс после перемещения
    show();
}

void Vehicle::moveUp(int screenHeight) {
    // Реализация чисто виртуального метода интерфейса IMovable
    int newY = y - speed;
    if (newY >= 30) {  // Учитываем размер мотоцикла
        moveTo(x, newY);
    }
}

void Vehicle::moveDown(int screenHeight) {
    // Реализация чисто виртуального метода интерфейса IMovable
    int newY = y + speed;
    if (newY <= screenHeight - 30) {  // Учитываем размер мотоцикла
        moveTo(x, newY);
    }
}

void Vehicle::moveLeft(int screenWidth) {
    // Реализация чисто виртуального метода интерфейса IMovable
    int newX = x - speed;
    if (newX >= 40) {  // Учитываем размер мотоцикла
        moveTo(newX, y);
    }
}

void Vehicle::moveRight(int screenWidth) {
    // Реализация чисто виртуального метода интерфейса IMovable
    int newX = x + speed;
    if (newX <= screenWidth - 40) {  // Учитываем размер мотоцикла
        moveTo(newX, y);
    }
}

// ============ РЕАЛИЗАЦИЯ КЛАССА SportBike ============
// Эти классы остаются практически без изменений, только обновлены override спецификаторы

SportBike::SportBike(int initX, int initY) : Vehicle(initX, initY, 100) {}

void SportBike::show() {
    visible = true;

    // Рисуем спортивный мотоцикл - яркий красный цвет, обтекаемая форма

    // === ОСНОВНОЙ КОРПУС ===
    HPEN   pen      = CreatePen(PS_SOLID, 3, RGB(200, 0, 0));  // Ярко-красный
    HBRUSH brush    = CreateSolidBrush(RGB(220, 0, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Обтекаемый корпус спортбайка
    Ellipse(bufferDC, x - 30, y - 15, x + 30, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === КОЛЕСА ===
    pen      = CreatePen(PS_SOLID, 2, RGB(50, 50, 50));  // Темно-серый
    brush    = CreateSolidBrush(RGB(80, 80, 80));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Переднее колесо
    Ellipse(bufferDC, x + 15, y - 10, x + 35, y + 10);
    // Заднее колесо
    Ellipse(bufferDC, x - 35, y - 10, x - 15, y + 10);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === РУЛЬ И СИДЕНЬЕ ===
    pen    = CreatePen(PS_SOLID, 2, RGB(0, 0, 0));  // Черный
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Руль спортбайка (низкий)
    MoveToEx(bufferDC, x + 20, y - 20, NULL);
    LineTo(bufferDC, x + 30, y - 25);
    MoveToEx(bufferDC, x + 10, y - 20, NULL);
    LineTo(bufferDC, x + 20, y - 25);

    // Спортивное сиденье
    brush    = CreateSolidBrush(RGB(0, 0, 0));
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);
    Rectangle(bufferDC, x - 20, y - 8, x + 5, y - 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === СПОРТИВНЫЕ ДЕТАЛИ ===
    pen    = CreatePen(PS_SOLID, 1, RGB(255, 255, 0));  // Желтые акценты
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Спортивные полосы
    MoveToEx(bufferDC, x - 25, y - 5, NULL);
    LineTo(bufferDC, x + 25, y - 5);
    MoveToEx(bufferDC, x - 25, y + 5, NULL);
    LineTo(bufferDC, x + 25, y + 5);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void SportBike::hide() {
    visible = false;

    // Стираем область мотоцикла белым цветом
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 40, y - 30, x + 40, y + 30);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА Cruiser ============

Cruiser::Cruiser(int initX, int initY) : Vehicle(initX, initY, 100) {}

void Cruiser::show() {
    visible = true;

    // Рисуем круизер - массивный, черный с хромированными деталями

    // === ОСНОВНОЙ КОРПУС ===
    HPEN   pen      = CreatePen(PS_SOLID, 4, RGB(20, 20, 20));  // Черный
    HBRUSH brush    = CreateSolidBrush(RGB(40, 40, 40));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Массивный корпус круизера
    Rectangle(bufferDC, x - 35, y - 12, x + 35, y + 12);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === КОЛЕСА (большие) ===
    pen      = CreatePen(PS_SOLID, 3, RGB(50, 50, 50));
    brush    = CreateSolidBrush(RGB(80, 80, 80));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Переднее колесо (большое)
    Ellipse(bufferDC, x + 10, y - 15, x + 40, y + 15);
    // Заднее колесо (большое)
    Ellipse(bufferDC, x - 40, y - 15, x - 10, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === РУЛЬ И СИДЕНЬЕ ===
    pen    = CreatePen(PS_SOLID, 3, RGB(200, 200, 200));  // Хром
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Высокий руль круизера
    MoveToEx(bufferDC, x + 15, y - 25, NULL);
    LineTo(bufferDC, x + 15, y - 40);
    MoveToEx(bufferDC, x + 10, y - 40, NULL);
    LineTo(bufferDC, x + 20, y - 40);

    // Широкое сиденье
    brush    = CreateSolidBrush(RGB(100, 50, 0));  // Коричневая кожа
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);
    Rectangle(bufferDC, x - 25, y - 10, x + 10, y - 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === ХРОМИРОВАННЫЕ ДЕТАЛИ ===
    pen    = CreatePen(PS_SOLID, 2, RGB(220, 220, 220));  // Блестящий хром
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Хромированные трубы
    MoveToEx(bufferDC, x - 30, y + 5, NULL);
    LineTo(bufferDC, x - 45, y + 15);
    MoveToEx(bufferDC, x - 30, y + 8, NULL);
    LineTo(bufferDC, x - 45, y + 18);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void Cruiser::hide() {
    visible = false;

    // Стираем область мотоцикла
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 50, y - 45, x + 45, y + 25);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА DirtBike ============

DirtBike::DirtBike(int initX, int initY) : Vehicle(initX, initY, 100) {}

void DirtBike::show() {
    visible = true;

    // Рисуем эндуро - оранжевый цвет, высокая подвеска, защита

    // === ОСНОВНОЙ КОРПУС ===
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(255, 140, 0));  // Оранжевый
    HBRUSH brush    = CreateSolidBrush(RGB(255, 165, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Компактный корпус эндуро
    Ellipse(bufferDC, x - 25, y - 10, x + 25, y + 10);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === КОЛЕСА С ГРЯЗЕВЫМИ ШИНАМИ ===
    pen      = CreatePen(PS_SOLID, 2, RGB(100, 50, 0));  // Коричневый (грязь)
    brush    = CreateSolidBrush(RGB(120, 80, 40));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Переднее колесо
    Ellipse(bufferDC, x + 12, y - 12, x + 35, y + 12);
    // Заднее колесо
    Ellipse(bufferDC, x - 35, y - 12, x - 12, y + 12);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === ВЫСОКАЯ ПОДВЕСКА ===
    pen    = CreatePen(PS_SOLID, 3, RGB(150, 150, 150));  // Серый металл
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Передняя вилка
    MoveToEx(bufferDC, x + 23, y - 12, NULL);
    LineTo(bufferDC, x + 23, y - 25);
    // Задний амортизатор
    MoveToEx(bufferDC, x - 23, y - 12, NULL);
    LineTo(bufferDC, x - 23, y - 25);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);

    // === РУЛЬ И СИДЕНЬЕ ===
    pen      = CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
    brush    = CreateSolidBrush(RGB(0, 0, 0));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Прямой руль эндуро
    MoveToEx(bufferDC, x + 15, y - 25, NULL);
    LineTo(bufferDC, x + 30, y - 25);
    MoveToEx(bufferDC, x + 22, y - 25, NULL);
    LineTo(bufferDC, x + 22, y - 30);

    // Спортивное сиденье
    Rectangle(bufferDC, x - 20, y - 8, x + 5, y - 5);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === ЗАЩИТНЫЕ ЭЛЕМЕНТЫ ===
    pen    = CreatePen(PS_SOLID, 1, RGB(50, 50, 50));  // Темная защита
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Защита двигателя
    MoveToEx(bufferDC, x - 15, y + 8, NULL);
    LineTo(bufferDC, x + 15, y + 8);
    LineTo(bufferDC, x + 10, y + 15);
    LineTo(bufferDC, x - 10, y + 15);
    LineTo(bufferDC, x - 15, y + 8);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void DirtBike::hide() {
    visible = false;

    // Стираем область мотоцикла
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 40, y - 35, x + 40, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА RoadObject ============
// ВАЖНЫЕ ИЗМЕНЕНИЯ: Теперь RoadObject наследует от интерфейсов IDisplayable и IRespawnable
// Метод respawn теперь реализуется через интерфейс IRespawnable с ключевым словом override

RoadObject::RoadObject(int initX, int initY) : Location(initX, initY), visible(true) {
    updateHitbox();
}

RoadObject::~RoadObject() = default;

Hitbox RoadObject::getHitbox() { return hitbox; }

void RoadObject::updateHitbox() {
    // Объекты на дороге имеют размер 40x30 пикселей (в 2 раза меньше мотоцикла)
    hitbox.left   = x - 20;
    hitbox.right  = x + 20;
    hitbox.top    = y - 15;
    hitbox.bottom = y + 15;
}

// ============ РЕАЛИЗАЦИЯ ИНТЕРФЕЙСА IDisplayable В КЛАССЕ RoadObject ============

bool RoadObject::isVisible() {
    // Реализация метода интерфейса IDisplayable
    return visible;
}

// ============ РЕАЛИЗАЦИЯ ИНТЕРФЕЙСА IRespawnable В КЛАССЕ RoadObject ============
// Этот метод был УДАЛЕН из первого задания и теперь возвращен через интерфейс

void RoadObject::respawn(int screenWidth, int screenHeight) {
    // Реализация чисто виртуального метода интерфейса IRespawnable
    constexpr int padding = 50;  // Отступ от краев экрана

    std::uniform_int_distribution<> distX(padding, screenWidth - padding);
    std::uniform_int_distribution<> distY(padding, screenHeight - padding);

    const int newX = distX(generator);
    const int newY = distY(generator);

    hide();
    x = newX;
    y = newY;
    updateHitbox();  // Обновляем хитбокс после перемещения
    show();
}

// ============ РЕАЛИЗАЦИЯ КЛАССА Rock ============

Rock::Rock(int initX, int initY) : RoadObject(initX, initY) {}

void Rock::show() {
    visible = true;

    // Рисуем камень серого цвета неправильной формы
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(100, 100, 100));
    HBRUSH brush    = CreateSolidBrush(RGB(120, 120, 120));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Неправильная форма камня
    POINT points[6] = {
        {x - 18, y + 10},
        {x - 5, y - 12},
        {x + 8, y - 15},
        {x + 20, y - 5},
        {x + 15, y + 12},
        {x - 10, y + 15}};
    Polygon(bufferDC, points, 6);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

void Rock::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

int Rock::getDamage() {
    std::uniform_int_distribution<> damageRange(5, 15);
    return damageRange(generator);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА Pothole ============

Pothole::Pothole(int initX, int initY) : RoadObject(initX, initY) {}

void Pothole::show() {
    visible = true;

    // Рисуем яму темно-коричневого цвета
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(80, 50, 20));
    HBRUSH brush    = CreateSolidBrush(RGB(60, 40, 20));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Овальная яма
    Ellipse(bufferDC, x - 20, y - 10, x + 20, y + 10);

    // Добавляем тени для глубины
    HBRUSH shadowBrush = CreateSolidBrush(RGB(40, 25, 10));
    SelectObject(bufferDC, shadowBrush);
    Ellipse(bufferDC, x - 15, y - 8, x + 15, y + 8);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(shadowBrush);
}

void Pothole::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 15, x + 25, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

int Pothole::getDamage() {
    std::uniform_int_distribution<> damageRange(10, 25);
    return damageRange(generator);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА Service ============

Service::Service(int initX, int initY) : RoadObject(initX, initY) {}

void Service::show() {
    visible = true;

    // Рисуем сервис зеленого цвета с крестом (медицинский символ)
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(0, 150, 0));
    HBRUSH brush    = CreateSolidBrush(RGB(0, 200, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Основание сервиса
    Rectangle(bufferDC, x - 20, y - 15, x + 20, y + 15);

    // Белый крест
    HPEN   crossPen   = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    HBRUSH crossBrush = CreateSolidBrush(RGB(255, 255, 255));
    SelectObject(bufferDC, crossPen);
    SelectObject(bufferDC, crossBrush);

    // Горизонтальная часть креста
    Rectangle(bufferDC, x - 12, y - 3, x + 12, y + 3);
    // Вертикальная часть креста
    Rectangle(bufferDC, x - 3, y - 12, x + 3, y + 12);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(crossPen);
    DeleteObject(crossBrush);
}

void Service::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА Transformer1 ============

Transformer1::Transformer1(int initX, int initY) : RoadObject(initX, initY) {}

void Transformer1::show() {
    visible = true;

    // Рисуем трансформер синего цвета со стрелкой по часовой стрелке
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(0, 0, 200));
    HBRUSH brush    = CreateSolidBrush(RGB(100, 100, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Основание трансформера (круг)
    Ellipse(bufferDC, x - 20, y - 15, x + 20, y + 15);

    // Стрелка по часовой стрелке
    HPEN arrowPen = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    SelectObject(bufferDC, arrowPen);

    // Кривая стрелка
    MoveToEx(bufferDC, x - 10, y - 8, NULL);
    LineTo(bufferDC, x + 8, y - 8);
    LineTo(bufferDC, x + 8, y + 8);

    // Наконечник стрелки
    MoveToEx(bufferDC, x + 8, y + 8, NULL);
    LineTo(bufferDC, x + 3, y + 3);
    MoveToEx(bufferDC, x + 8, y + 8, NULL);
    LineTo(bufferDC, x + 13, y + 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(arrowPen);
}

void Transformer1::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА Transformer2 ============

Transformer2::Transformer2(int initX, int initY) : RoadObject(initX, initY) {}

void Transformer2::show() {
    visible = true;

    // Рисуем трансформер фиолетового цвета со стрелкой против часовой стрелки
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(128, 0, 128));
    HBRUSH brush    = CreateSolidBrush(RGB(200, 100, 200));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Основание трансформера (круг)
    Ellipse(bufferDC, x - 20, y - 15, x + 20, y + 15);

    // Стрелка против часовой стрелки
    HPEN arrowPen = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    SelectObject(bufferDC, arrowPen);

    // Кривая стрелка
    MoveToEx(bufferDC, x + 10, y - 8, NULL);
    LineTo(bufferDC, x - 8, y - 8);
    LineTo(bufferDC, x - 8, y + 8);

    // Наконечник стрелки
    MoveToEx(bufferDC, x - 8, y + 8, NULL);
    LineTo(bufferDC, x - 3, y + 3);
    MoveToEx(bufferDC, x - 8, y + 8, NULL);
    LineTo(bufferDC, x - 13, y + 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(arrowPen);
}

void Transformer2::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}
/************************************************************
 *                  ЗАДАНИЕ 2: НАСЛЕДОВАНИЕ ОТ ИНТЕРФЕЙСА  *
 *----------------------------------------------------------*
 * Project Type  : Win64 Console Application                *
 * Project Name  : task2_interfaces                         *
 * File Name     : main.cpp                                 *
 * Language      : CPP, MSVC 2022                           *
 * Programmer    : Student                                  *
 * Created       : 30.06.2025                               *
 * Last Revision : 30.06.2025                               *
 * Comment(s)    : Демонстрация наследования от интерфейса  *
 *                 Интерфейсы IDisplayable, IMovable,       *
 *                 IRespawnable с чисто виртуальными        *
 *                 методами без полей данных                *
 ************************************************************/

#include <windows.h>
#include <random>
#include "classes.hpp"

#define KEY_DOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define _UNICODE

HWND hwnd;      // Глобальный дескриптор окна
HDC  bufferDC;  // Глобальный HDC, используемый при отрисовке

// Генератор случайных чисел для main.cpp (отдельный от classes.cpp)
static std::random_device mainRandomDevice;
static std::mt19937       mainGenerator(mainRandomDevice());

// Индексы типов мотоциклов для матриц переходов
enum MotorcycleType {
    SPORTBIKE = 0,
    CRUISER   = 1,
    DIRTBIKE  = 2,
    MOTORCYCLE_COUNT
};

// Глобальные объекты мотоциклов (создаются в одной позиции)
SportBike sportbike(400, 300);
Cruiser   cruiser(400, 300);
DirtBike  dirtbike(400, 300);

// Глобальные объекты на дороге
Rock         rock(150, 150);
Pothole      pothole(650, 450);
Service      service(400, 150);
Transformer1 transformer1(200, 450);  // Меняет тип по часовой стрелке
Transformer2 transformer2(600, 150);  // Меняет тип против часовой стрелки

// =====================================================================
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА ЧЕРЕЗ ИНТЕРФЕЙСЫ
// =====================================================================

// Массив указателей на интерфейс IMovable (полиморфизм через интерфейс)
// Все мотоциклы реализуют интерфейс IMovable, поэтому могут быть использованы полиморфно
IMovable* movableObjects[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Массив указателей на базовый класс Vehicle (классическое наследование)
Vehicle* motorcycles[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Массив указателей на интерфейс IRespawnable (полиморфизм через интерфейс)
// Все объекты дороги реализуют интерфейс IRespawnable
IRespawnable* respawnableObjects[] = {&rock, &pothole, &service, &transformer1, &transformer2};
const int     RESPAWNABLE_COUNT    = sizeof(respawnableObjects) / sizeof(respawnableObjects[0]);

// Массив указателей на интерфейс IDisplayable (полиморфизм через интерфейс)
// Все визуальные объекты реализуют интерфейс IDisplayable
IDisplayable* displayableObjects[] = {&sportbike, &cruiser, &dirtbike, &rock, &pothole, &service, &transformer1, &transformer2};
const int     DISPLAYABLE_COUNT    = sizeof(displayableObjects) / sizeof(displayableObjects[0]);

// Матрицы переходов для трансформеров (те же, что в первом задании)
const MotorcycleType clockwiseTransitions[MOTORCYCLE_COUNT] = {
    CRUISER,   // SportBike -> Cruiser
    DIRTBIKE,  // Cruiser -> DirtBike
    SPORTBIKE  // DirtBike -> SportBike
};

const MotorcycleType counterClockwiseTransitions[MOTORCYCLE_COUNT] = {
    DIRTBIKE,   // SportBike -> DirtBike
    SPORTBIKE,  // Cruiser -> SportBike
    CRUISER     // DirtBike -> Cruiser
};

// Текущий тип активного мотоцикла
MotorcycleType activeMotorcycleType = SPORTBIKE;

// Указатели на текущий активный мотоцикл через разные интерфейсы (демонстрация полиморфизма)
Vehicle*      activeVehiclePtr = motorcycles[activeMotorcycleType];         // Через базовый класс
IMovable*     activeMovablePtr = movableObjects[activeMotorcycleType];      // Через интерфейс IMovable
IDisplayable* activeDisplayPtr = displayableObjects[activeMotorcycleType];  // Через интерфейс IDisplayable

// Глобальная функция проверки коллизий между мотоциклом и объектом на дороге
// Демонстрирует работу с базовыми классами (Vehicle и RoadObject)
bool isCollision(Vehicle* motorcycle, RoadObject* roadObj) {
    if (!motorcycle || !roadObj) return false;

    // Используем интерфейс IDisplayable для проверки видимости
    IDisplayable* motorcycleDisplay = motorcycle;  // Автоматическое приведение к интерфейсу
    IDisplayable* objectDisplay     = roadObj;     // Автоматическое приведение к интерфейсу

    if (!motorcycleDisplay->isVisible() || !objectDisplay->isVisible()) return false;

    Hitbox motorcycleHitbox = motorcycle->getHitbox();
    Hitbox objectHitbox     = roadObj->getHitbox();

    // Проверяем пересечение хитбоксов
    return (objectHitbox.left <= motorcycleHitbox.right &&
            objectHitbox.right >= motorcycleHitbox.left &&
            objectHitbox.top <= motorcycleHitbox.bottom &&
            objectHitbox.bottom >= motorcycleHitbox.top);
}

// Функция для изменения активного мотоцикла (демонстрация работы с интерфейсами)
void ChangeActiveMotorcycle(MotorcycleType newMotorcycleType) {
    // Получаем текущие координаты и здоровье через базовый класс Vehicle
    int x      = activeVehiclePtr->getX();
    int y      = activeVehiclePtr->getY();
    int health = activeVehiclePtr->getHealth();

    // Скрываем текущий мотоцикл через интерфейс IDisplayable
    activeDisplayPtr->hide();

    // Устанавливаем новый тип мотоцикла
    activeMotorcycleType = newMotorcycleType;

    // Обновляем все указатели на активный мотоцикл
    activeVehiclePtr = motorcycles[activeMotorcycleType];         // Базовый класс
    activeMovablePtr = movableObjects[activeMotorcycleType];      // Интерфейс IMovable
    activeDisplayPtr = displayableObjects[activeMotorcycleType];  // Интерфейс IDisplayable

    // Устанавливаем здоровье нового мотоцикла равным предыдущему
    while (activeVehiclePtr->getHealth() > health) {
        activeVehiclePtr->takeDamage(1);
    }
    if (activeVehiclePtr->getHealth() < health) {
        // Если нужно увеличить здоровье, ремонтируем и снова уменьшаем
        activeVehiclePtr->repair();
        while (activeVehiclePtr->getHealth() > health) {
            activeVehiclePtr->takeDamage(1);
        }
    }

    // Перемещаем мотоцикл через интерфейс IMovable и показываем через IDisplayable
    activeMovablePtr->moveTo(x, y);
    activeDisplayPtr->show();
}

// Функция для демонстрации полиморфного респавна всех объектов через интерфейс IRespawnable
void RespawnAllRoadObjects() {
    // Получаем размеры клиентской области
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Респавним все объекты полиморфно через интерфейс IRespawnable
    for (int i = 0; i < RESPAWNABLE_COUNT; i++) {
        respawnableObjects[i]->respawn(width, height);
    }
}

// Функция проверки всех коллизий
void CheckCollisions() {
    bool collision = false;

    // Получаем размеры клиентской области
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Проверяем коллизию с камнем (наносит урон 5-15)
    if (isCollision(activeVehiclePtr, &rock)) {
        collision  = true;
        int damage = rock.getDamage();
        activeVehiclePtr->takeDamage(damage);

        // Респавним через интерфейс IRespawnable
        IRespawnable* rockRespawnable = &rock;
        rockRespawnable->respawn(width, height);
    }

    // Проверяем коллизию с ямой (наносит урон 10-25)
    if (isCollision(activeVehiclePtr, &pothole)) {
        collision  = true;
        int damage = pothole.getDamage();
        activeVehiclePtr->takeDamage(damage);

        // Респавним через интерфейс IRespawnable
        IRespawnable* potholeRespawnable = &pothole;
        potholeRespawnable->respawn(width, height);
    }

    // Проверяем коллизию с сервисом (полное восстановление)
    if (isCollision(activeVehiclePtr, &service)) {
        collision = true;
        activeVehiclePtr->repair();  // Полное восстановление здоровья

        // Респавним через интерфейс IRespawnable
        IRespawnable* serviceRespawnable = &service;
        serviceRespawnable->respawn(width, height);
    }

    // Проверяем коллизию с трансформером 1 (по часовой стрелке)
    if (isCollision(activeVehiclePtr, &transformer1)) {
        collision = true;

        // Используем матрицу переходов по часовой стрелке
        MotorcycleType newType = clockwiseTransitions[activeMotorcycleType];
        ChangeActiveMotorcycle(newType);

        // Респавним через интерфейс IRespawnable
        IRespawnable* transformer1Respawnable = &transformer1;
        transformer1Respawnable->respawn(width, height);
    }

    // Проверяем коллизию с трансформером 2 (против часовой стрелки)
    if (isCollision(activeVehiclePtr, &transformer2)) {
        collision = true;

        // Используем матрицу переходов против часовой стрелки
        MotorcycleType newType = counterClockwiseTransitions[activeMotorcycleType];
        ChangeActiveMotorcycle(newType);

        // Респавним через интерфейс IRespawnable
        IRespawnable* transformer2Respawnable = &transformer2;
        transformer2Respawnable->respawn(width, height);
    }

    if (collision) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Функция обработки ввода с клавиатуры (управление мотоциклом через интерфейс IMovable)
void CheckKeyboardInput() {
    bool needRedraw = false;

    // Получаем размеры клиентской области
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // ВАЖНО: Движение осуществляется через интерфейс IMovable, а не напрямую через Vehicle
    // Это демонстрирует принцип "программирования к интерфейсу, а не к реализации"

    if (KEY_DOWN('W') || KEY_DOWN('w') || KEY_DOWN(VK_UP)) {
        activeMovablePtr->moveUp(height);  // Вызов через интерфейс IMovable
        needRedraw = true;
    }
    if (KEY_DOWN('S') || KEY_DOWN('s') || KEY_DOWN(VK_DOWN)) {
        activeMovablePtr->moveDown(height);  // Вызов через интерфейс IMovable
        needRedraw = true;
    }
    if (KEY_DOWN('A') || KEY_DOWN('a') || KEY_DOWN(VK_LEFT)) {
        activeMovablePtr->moveLeft(width);  // Вызов через интерфейс IMovable
        needRedraw = true;
    }
    if (KEY_DOWN('D') || KEY_DOWN('d') || KEY_DOWN(VK_RIGHT)) {
        activeMovablePtr->moveRight(width);  // Вызов через интерфейс IMovable
        needRedraw = true;
    }

    // Дополнительная функция - респавн всех объектов по нажатию R
    if (KEY_DOWN('R') || KEY_DOWN('r')) {
        RespawnAllRoadObjects();  // Демонстрирует полиморфный респавн через интерфейс
        needRedraw = true;
    }

    CheckCollisions();  // Проверка коллизий после каждого движения
    if (needRedraw) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Обработчик сообщений окна
LRESULT CALLBACK WndProc(HWND hwnd, const UINT msg, const WPARAM wParam, const LPARAM lParam) {
    PAINTSTRUCT ps;

    switch (msg) {
        case WM_PAINT: {
            HDC hdcLocal = BeginPaint(hwnd, &ps);

            // Получаем размеры клиентской области
            RECT rect;
            GetClientRect(hwnd, &rect);
            const int width  = rect.right - rect.left;
            const int height = rect.bottom - rect.top;

            // Создаем совместимый DC и битмап в памяти для двойной буферизации
            HDC     memDC     = CreateCompatibleDC(hdcLocal);
            HBITMAP memBitmap = CreateCompatibleBitmap(hdcLocal, width, height);
            HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, memBitmap);

            // Заполняем фон светло-серым цветом (дорога)
            HBRUSH bgBrush  = CreateSolidBrush(RGB(200, 200, 200));  // Серая дорога
            HBRUSH oldBrush = (HBRUSH)SelectObject(memDC, bgBrush);
            FillRect(memDC, &rect, bgBrush);
            SelectObject(memDC, oldBrush);
            DeleteObject(bgBrush);

            bufferDC = memDC;  // Устанавливаем глобальный буфер HDC

            // ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: Отрисовываем активный мотоцикл через интерфейс IDisplayable
            // Вместо прямого вызова метода show() класса, мы используем интерфейс
            activeDisplayPtr->show();

            // Отрисовываем все объекты на дороге через их соответствующие интерфейсы
            // Каждый объект реализует интерфейс IDisplayable по-своему
            IDisplayable* rockDisplay         = &rock;
            IDisplayable* potholeDisplay      = &pothole;
            IDisplayable* serviceDisplay      = &service;
            IDisplayable* transformer1Display = &transformer1;
            IDisplayable* transformer2Display = &transformer2;

            rockDisplay->show();
            potholeDisplay->show();
            serviceDisplay->show();
            transformer1Display->show();
            transformer2Display->show();

            // Отображаем информацию о мотоцикле в углу экрана
            SetBkMode(memDC, TRANSPARENT);
            SetTextColor(memDC, RGB(0, 0, 0));

            char        info[300];
            const char* typeName = "";
            switch (activeMotorcycleType) {
                case SPORTBIKE: typeName = "SportBike"; break;
                case CRUISER: typeName = "Cruiser"; break;
                case DIRTBIKE: typeName = "DirtBike"; break;
            }

            wsprintfA(info, "TASK 2: INTERFACES | Motorcycle: %s | Health: %d%% | Speed: %d px/step | Press R to respawn all objects",
                      typeName, activeVehiclePtr->getHealth(), activeVehiclePtr->getSpeed());
            TextOutA(memDC, 10, 10, info, lstrlenA(info));

            // Демонстрация интерфейсов в информации
            wsprintfA(info, "Interfaces: IDisplayable (show/hide), IMovable (movement), IRespawnable (respawn)");
            TextOutA(memDC, 10, 30, info, lstrlenA(info));

            // Копируем результат из памяти на экран
            BitBlt(hdcLocal, 0, 0, width, height, memDC, 0, 0, SRCCOPY);

            SelectObject(memDC, oldBitmap);
            DeleteObject(memBitmap);
            DeleteDC(memDC);

            EndPaint(hwnd, &ps);
        } break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// Точка входа в приложение
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
    // Регистрация класса окна
    WNDCLASSEX wc    = {0};
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "task2_interfaces";
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Ошибка регистрации окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    // Создание окна
    hwnd = CreateWindowEx(
        0,
        "task2_interfaces",
        "Задание 2: Наследование от интерфейса - Мотоциклы с интерфейсами",
        WS_OVERLAPPEDWINDOW | WS_MAXIMIZE,
        CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT,
        nullptr, nullptr, hInstance, nullptr);

    if (hwnd == NULL) {
        MessageBox(NULL, "Ошибка создания окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    nShowCmd = SW_MAXIMIZE;
    ShowWindow(hwnd, nShowCmd);
    UpdateWindow(hwnd);

    // Получаем размеры клиентской области для инициализации объектов
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Инициализация мотоциклов в центре экрана
    // Все мотоциклы создаются в одной позиции, но показан только один
    sportbike = SportBike(width / 2, height / 2);
    cruiser   = Cruiser(width / 2, height / 2);
    dirtbike  = DirtBike(width / 2, height / 2);

    // Инициализация объектов на дороге в случайных позициях через интерфейс IRespawnable
    RespawnAllRoadObjects();

    // Переинициализация массивов указателей после пересоздания объектов
    motorcycles[0] = &sportbike;
    motorcycles[1] = &cruiser;
    motorcycles[2] = &dirtbike;

    movableObjects[0] = &sportbike;  // Интерфейс IMovable
    movableObjects[1] = &cruiser;
    movableObjects[2] = &dirtbike;

    displayableObjects[0] = &sportbike;  // Интерфейс IDisplayable (первые 3 элемента - мотоциклы)
    displayableObjects[1] = &cruiser;
    displayableObjects[2] = &dirtbike;
    // Остальные элементы - объекты дороги (уже инициализированы в объявлении массива)

    // Случайный выбор начального типа мотоцикла
    std::uniform_int_distribution<> typeRange(0, MOTORCYCLE_COUNT - 1);
    activeMotorcycleType = static_cast<MotorcycleType>(typeRange(mainGenerator));

    // Обновляем все указатели на активный мотоцикл
    activeVehiclePtr = motorcycles[activeMotorcycleType];
    activeMovablePtr = movableObjects[activeMotorcycleType];
    activeDisplayPtr = displayableObjects[activeMotorcycleType];

    // Изначально скрываем все мотоциклы через интерфейс IDisplayable, затем показываем только активный
    for (int i = 0; i < MOTORCYCLE_COUNT; i++) {
        displayableObjects[i]->hide();  // Полиморфный вызов через интерфейс
    }

    activeDisplayPtr->show();  // Показываем случайно выбранный мотоцикл через интерфейс

    InvalidateRect(hwnd, NULL, FALSE);

    // Основной цикл обработки сообщений
    MSG msg;
    while (true) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) {
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        } else {
            CheckKeyboardInput();  // Проверяем нажатия клавиш
            Sleep(16);             // ~60 FPS
        }
    }

    return (int)msg.wParam;
}
/************************************************************
 *                  ЗАДАНИЕ 3: ИСПОЛЬЗОВАНИЕ ПОЛИМОРФИЗМА   *
 *----------------------------------------------------------*
 * Project Type  : Win64 Console Application                *
 * Project Name  : task3_polymorphism                       *
 * File Name     : main.cpp                                 *
 * Language      : CPP, MSVC 2022                           *
 * Programmer    : Student                                  *
 * Created       : 30.06.2025                               *
 * Last Revision : 30.06.2025                               *
 * Comment(s)    : Демонстрация полиморфизма - одни и те же *
 *                 операции выполняются по-разному в        *
 *                 зависимости от типа объекта              *
 ************************************************************/

#include <windows.h>
#include <random>
#include "classes.hpp"

#define KEY_DOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define _UNICODE

HWND hwnd;      // Глобальный дескриптор окна
HDC  bufferDC;  // Глобальный HDC, используемый при отрисовке

// Генератор случайных чисел для main.cpp
static std::random_device mainRandomDevice;
static std::mt19937       mainGenerator(mainRandomDevice());

// Индексы типов мотоциклов для матриц переходов
enum MotorcycleType {
    SPORTBIKE = 0,
    CRUISER   = 1,
    DIRTBIKE  = 2,
    MOTORCYCLE_COUNT
};

// Глобальные объекты мотоциклов (создаются в одной позиции)
SportBike sportbike(400, 300);
Cruiser   cruiser(400, 300);
DirtBike  dirtbike(400, 300);

// Глобальные объекты на дороге
Rock         rock(150, 150);
Pothole      pothole(650, 450);
Service      service(400, 150);
Transformer1 transformer1(200, 450);
Transformer2 transformer2(600, 150);

// =====================================================================
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА ЧЕРЕЗ МАССИВЫ УКАЗАТЕЛЕЙ НА ИНТЕРФЕЙСЫ
// =====================================================================

// ПОЛИМОРФНЫЕ МАССИВЫ: Один интерфейс - разные реализации
// Каждый массив демонстрирует, как через единый интерфейс можно работать с разными объектами

// Массив для демонстрации полиморфизма звуков - все объекты реализуют ISoundEmitter по-разному
ISoundEmitter* soundEmitters[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Массив для демонстрации полиморфизма описаний мотоциклов - все реализуют IDescriptive по-разному
IDescriptive* motorcycleDescriptors[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Массив для демонстрации полиморфизма эффектов - все реализуют IEffectGenerator по-разному
IEffectGenerator* effectGenerators[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Массив для демонстрации полиморфизма движения - все реализуют IMovable по-разному
IMovable* movableObjects[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Массив указателей на базовый класс Vehicle (для доступа к специфичным методам)
Vehicle* motorcycles[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Массив для демонстрации полиморфизма описаний объектов дороги
IDescriptive* roadDescriptors[]      = {&rock, &pothole, &service, &transformer1, &transformer2};
const int     ROAD_DESCRIPTORS_COUNT = sizeof(roadDescriptors) / sizeof(roadDescriptors[0]);

// Массив для демонстрации полиморфизма респавна
IRespawnable* respawnableObjects[] = {&rock, &pothole, &service, &transformer1, &transformer2};
const int     RESPAWNABLE_COUNT    = sizeof(respawnableObjects) / sizeof(respawnableObjects[0]);

// Массив для демонстрации полиморфизма отображения
IDisplayable* displayableObjects[] = {&sportbike, &cruiser, &dirtbike, &rock, &pothole, &service, &transformer1, &transformer2};
const int     DISPLAYABLE_COUNT    = sizeof(displayableObjects) / sizeof(displayableObjects[0]);

// Матрицы переходов для трансформеров
const MotorcycleType clockwiseTransitions[MOTORCYCLE_COUNT] = {
    CRUISER,   // SportBike -> Cruiser
    DIRTBIKE,  // Cruiser -> DirtBike
    SPORTBIKE  // DirtBike -> SportBike
};

const MotorcycleType counterClockwiseTransitions[MOTORCYCLE_COUNT] = {
    DIRTBIKE,   // SportBike -> DirtBike
    SPORTBIKE,  // Cruiser -> SportBike
    CRUISER     // DirtBike -> Cruiser
};

// Текущий тип активного мотоцикла
MotorcycleType activeMotorcycleType = SPORTBIKE;

// Указатели на текущий активный мотоцикл через разные интерфейсы (ПОЛИМОРФИЗМ!)
Vehicle*          activeVehiclePtr     = motorcycles[activeMotorcycleType];            // Базовый класс
IMovable*         activeMovablePtr     = movableObjects[activeMotorcycleType];         // Интерфейс движения
IDisplayable*     activeDisplayPtr     = displayableObjects[activeMotorcycleType];     // Интерфейс отображения
ISoundEmitter*    activeSoundPtr       = soundEmitters[activeMotorcycleType];          // Интерфейс звуков
IDescriptive*     activeDescriptivePtr = motorcycleDescriptors[activeMotorcycleType];  // Интерфейс описания
IEffectGenerator* activeEffectPtr      = effectGenerators[activeMotorcycleType];       // Интерфейс эффектов

// =====================================================================
// ПОЛИМОРФНЫЕ ФУНКЦИИ: ДЕМОНСТРАЦИЯ РАБОТЫ С ИНТЕРФЕЙСАМИ
// =====================================================================

// ПОЛИМОРФНАЯ ФУНКЦИЯ 1: Демонстрирует звуки всех мотоциклов через единый интерфейс
void DemonstratePolymorphicSounds() {
    // КЛЮЧЕВАЯ ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА:
    // Один цикл, один интерфейс (ISoundEmitter*), но каждый объект ведет себя по-своему!

    for (int i = 0; i < MOTORCYCLE_COUNT; i++) {
        // Вызываем одни и те же методы через интерфейс...
        const char* engineSound = soundEmitters[i]->getEngineSound();  // ПОЛИМОРФНЫЙ ВЫЗОВ!
        const char* hornSound   = soundEmitters[i]->getHornSound();    // ПОЛИМОРФНЫЙ ВЫЗОВ!

        // ...но получаем разные результаты в зависимости от реального типа объекта
        // SportBike вернет звуки гоночного мотоцикла
        // Cruiser вернет звуки мощного круизера
        // DirtBike вернет звуки внедорожного мотоцикла

        // Здесь могла бы быть обработка звуков (в реальной игре - воспроизведение аудио)
    }
}

// ПОЛИМОРФНАЯ ФУНКЦИЯ 2: Получает описания всех объектов через единый интерфейс
void GetPolymorphicDescriptions() {
    // Демонстрируем полиморфизм: один интерфейс IDescriptive, разные описания

    // Сначала описания мотоциклов
    for (int i = 0; i < MOTORCYCLE_COUNT; i++) {
        const char* typeName    = motorcycleDescriptors[i]->getTypeName();        // ПОЛИМОРФНЫЙ ВЫЗОВ!
        const char* description = motorcycleDescriptors[i]->getDescription();     // ПОЛИМОРФНЫЙ ВЫЗОВ!
        int         strength    = motorcycleDescriptors[i]->getEffectStrength();  // ПОЛИМОРФНЫЙ ВЫЗОВ!

        // Каждый тип мотоцикла описывает себя уникально через один интерфейс
    }

    // Затем описания объектов дороги
    for (int i = 0; i < ROAD_DESCRIPTORS_COUNT; i++) {
        const char* typeName    = roadDescriptors[i]->getTypeName();        // ПОЛИМОРФНЫЙ ВЫЗОВ!
        const char* description = roadDescriptors[i]->getDescription();     // ПОЛИМОРФНЫЙ ВЫЗОВ!
        int         strength    = roadDescriptors[i]->getEffectStrength();  // ПОЛИМОРФНЫЙ ВЫЗОВ!

        // Rock, Pothole, Service, Transformer1, Transformer2 - все описывают себя по-разному
    }
}

// ПОЛИМОРФНАЯ ФУНКЦИЯ 3: Респавнит все объекты через единый интерфейс
void PolymorphicRespawnAll() {
    // Получаем размеры экрана
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: Один метод respawn(), разные реализации
    for (int i = 0; i < RESPAWNABLE_COUNT; i++) {
        respawnableObjects[i]->respawn(width, height);  // ПОЛИМОРФНЫЙ ВЫЗОВ!

        // Каждый объект респавнится по-своему через единый интерфейс IRespawnable
        // Но мы не знаем и не должны знать, как именно каждый объект это делает
    }
}

// ПОЛИМОРФНАЯ ФУНКЦИЯ 4: Скрывает и показывает все объекты через единый интерфейс
void PolymorphicShowHideAll(bool show) {
    // МОЩНАЯ ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: Один интерфейс управляет всеми визуальными объектами
    for (int i = 0; i < DISPLAYABLE_COUNT; i++) {
        if (show) {
            displayableObjects[i]->show();  // ПОЛИМОРФНЫЙ ВЫЗОВ!
        } else {
            displayableObjects[i]->hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ!
        }

        // SportBike рисует красный гоночный мотоцикл
        // Cruiser рисует черный массивный мотоцикл
        // DirtBike рисует оранжевый внедорожный мотоцикл
        // Rock рисует серый неровный камень
        // И так далее - все через один интерфейс, но каждый по-своему!
    }
}

// Функция проверки коллизий (аналогична предыдущим заданиям)
bool isCollision(Vehicle* motorcycle, RoadObject* roadObj) {
    if (!motorcycle || !roadObj) return false;

    // Используем полиморфизм для проверки видимости через интерфейс IDisplayable
    IDisplayable* motorcycleDisplay = motorcycle;
    IDisplayable* objectDisplay     = roadObj;

    if (!motorcycleDisplay->isVisible() || !objectDisplay->isVisible()) return false;

    Hitbox motorcycleHitbox = motorcycle->getHitbox();
    Hitbox objectHitbox     = roadObj->getHitbox();

    return (objectHitbox.left <= motorcycleHitbox.right &&
            objectHitbox.right >= motorcycleHitbox.left &&
            objectHitbox.top <= motorcycleHitbox.bottom &&
            objectHitbox.bottom >= motorcycleHitbox.top);
}

// Функция изменения активного мотоцикла с демонстрацией полиморфизма
void ChangeActiveMotorcycle(MotorcycleType newMotorcycleType) {
    // Получаем данные от текущего мотоцикла через полиморфные интерфейсы
    int x      = activeVehiclePtr->getX();       // Через базовый класс
    int y      = activeVehiclePtr->getY();       // Через базовый класс
    int health = activeVehiclePtr->getHealth();  // Через базовый класс

    // Скрываем текущий мотоцикл через полиморфный интерфейс отображения
    activeDisplayPtr->hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип скрывает себя по-своему

    // Устанавливаем новый тип мотоцикла
    activeMotorcycleType = newMotorcycleType;

    // Обновляем ВСЕ полиморфные указатели на новый объект
    activeVehiclePtr     = motorcycles[activeMotorcycleType];
    activeMovablePtr     = movableObjects[activeMotorcycleType];
    activeDisplayPtr     = displayableObjects[activeMotorcycleType];
    activeSoundPtr       = soundEmitters[activeMotorcycleType];
    activeDescriptivePtr = motorcycleDescriptors[activeMotorcycleType];
    activeEffectPtr      = effectGenerators[activeMotorcycleType];

    // Синхронизируем здоровье
    while (activeVehiclePtr->getHealth() > health) {
        activeVehiclePtr->takeDamage(1);
    }
    if (activeVehiclePtr->getHealth() < health) {
        activeVehiclePtr->repair();
        while (activeVehiclePtr->getHealth() > health) {
            activeVehiclePtr->takeDamage(1);
        }
    }

    // Перемещаем и показываем новый мотоцикл через полиморфные интерфейсы
    activeMovablePtr->moveTo(x, y);  // ПОЛИМОРФНЫЙ ВЫЗОВ - moveTo() с эффектами
    activeDisplayPtr->show();        // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип рисует себя по-своему
}

// Функция проверки коллизий с демонстрацией полиморфизма
void CheckCollisions() {
    bool collision = false;
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Проверяем коллизию с камнем
    if (isCollision(activeVehiclePtr, &rock)) {
        collision  = true;
        int damage = rock.getDamage();
        activeVehiclePtr->takeDamage(damage);

        // ПОЛИМОРФНЫЙ РЕСПАВН через интерфейс IRespawnable
        IRespawnable* rockRespawnable = &rock;
        rockRespawnable->respawn(width, height);  // ПОЛИМОРФНЫЙ ВЫЗОВ!
    }

    // Проверяем коллизию с ямой
    if (isCollision(activeVehiclePtr, &pothole)) {
        collision  = true;
        int damage = pothole.getDamage();
        activeVehiclePtr->takeDamage(damage);

        // ПОЛИМОРФНЫЙ РЕСПАВН через интерфейс IRespawnable
        IRespawnable* potholeRespawnable = &pothole;
        potholeRespawnable->respawn(width, height);  // ПОЛИМОРФНЫЙ ВЫЗОВ!
    }

    // Проверяем коллизию с сервисом
    if (isCollision(activeVehiclePtr, &service)) {
        collision = true;
        activeVehiclePtr->repair();

        // ПОЛИМОРФНЫЙ РЕСПАВН через интерфейс IRespawnable
        IRespawnable* serviceRespawnable = &service;
        serviceRespawnable->respawn(width, height);  // ПОЛИМОРФНЫЙ ВЫЗОВ!
    }

    // Проверяем коллизии с трансформерами
    if (isCollision(activeVehiclePtr, &transformer1)) {
        collision              = true;
        MotorcycleType newType = clockwiseTransitions[activeMotorcycleType];
        ChangeActiveMotorcycle(newType);

        IRespawnable* transformer1Respawnable = &transformer1;
        transformer1Respawnable->respawn(width, height);  // ПОЛИМОРФНЫЙ ВЫЗОВ!
    }

    if (isCollision(activeVehiclePtr, &transformer2)) {
        collision              = true;
        MotorcycleType newType = counterClockwiseTransitions[activeMotorcycleType];
        ChangeActiveMotorcycle(newType);

        IRespawnable* transformer2Respawnable = &transformer2;
        transformer2Respawnable->respawn(width, height);  // ПОЛИМОРФНЫЙ ВЫЗОВ!
    }

    if (collision) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Функция обработки ввода с демонстрацией полиморфного движения
void CheckKeyboardInput() {
    bool needRedraw = false;
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // КЛЮЧЕВАЯ ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА В ДВИЖЕНИИ:
    // Мы вызываем одни и те же методы движения через интерфейс IMovable,
    // но каждый тип мотоцикла создает свои уникальные визуальные эффекты!

    if (KEY_DOWN('W') || KEY_DOWN('w') || KEY_DOWN(VK_UP)) {
        activeMovablePtr->moveUp(height);  // ПОЛИМОРФНЫЙ ВЫЗОВ с эффектами!
        needRedraw = true;
    }
    if (KEY_DOWN('S') || KEY_DOWN('s') || KEY_DOWN(VK_DOWN)) {
        activeMovablePtr->moveDown(height);  // ПОЛИМОРФНЫЙ ВЫЗОВ с эффектами!
        needRedraw = true;
    }
    if (KEY_DOWN('A') || KEY_DOWN('a') || KEY_DOWN(VK_LEFT)) {
        activeMovablePtr->moveLeft(width);  // ПОЛИМОРФНЫЙ ВЫЗОВ с эффектами!
        needRedraw = true;
    }
    if (KEY_DOWN('D') || KEY_DOWN('d') || KEY_DOWN(VK_RIGHT)) {
        activeMovablePtr->moveRight(width);  // ПОЛИМОРФНЫЙ ВЫЗОВ с эффектами!
        needRedraw = true;
    }

    // Дополнительные демонстрации полиморфизма по нажатию клавиш
    if (KEY_DOWN('R') || KEY_DOWN('r')) {
        PolymorphicRespawnAll();  // Полиморфный респавн всех объектов
        needRedraw = true;
    }

    if (KEY_DOWN('H') || KEY_DOWN('h')) {
        // Демонстрация полиморфного скрытия/показа
        static bool hidden = false;
        hidden             = !hidden;
        PolymorphicShowHideAll(!hidden);
        needRedraw = true;
    }

    // Автоматически вызываем полиморфные функции для демонстрации
    DemonstratePolymorphicSounds();  // Демонстрируем звуки
    GetPolymorphicDescriptions();    // Получаем описания

    CheckCollisions();
    if (needRedraw) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Обработчик сообщений окна
LRESULT CALLBACK WndProc(HWND hwnd, const UINT msg, const WPARAM wParam, const LPARAM lParam) {
    PAINTSTRUCT ps;

    switch (msg) {
        case WM_PAINT: {
            HDC hdcLocal = BeginPaint(hwnd, &ps);

            RECT rect;
            GetClientRect(hwnd, &rect);
            const int width  = rect.right - rect.left;
            const int height = rect.bottom - rect.top;

            HDC     memDC     = CreateCompatibleDC(hdcLocal);
            HBITMAP memBitmap = CreateCompatibleBitmap(hdcLocal, width, height);
            HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, memBitmap);

            HBRUSH bgBrush  = CreateSolidBrush(RGB(200, 200, 200));
            HBRUSH oldBrush = (HBRUSH)SelectObject(memDC, bgBrush);
            FillRect(memDC, &rect, bgBrush);
            SelectObject(memDC, oldBrush);
            DeleteObject(bgBrush);

            bufferDC = memDC;

            // ПОЛИМОРФНОЕ ОТОБРАЖЕНИЕ: Показываем активный мотоцикл через интерфейс IDisplayable
            activeDisplayPtr->show();  // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый тип рисует себя уникально!

            // ПОЛИМОРФНОЕ ОТОБРАЖЕНИЕ всех объектов дороги через интерфейс IDisplayable
            for (int i = 3; i < DISPLAYABLE_COUNT; i++) {  // Начинаем с 3, чтобы пропустить мотоциклы
                displayableObjects[i]->show();             // ПОЛИМОРФНЫЙ ВЫЗОВ - каждый объект рисует себя уникально!
            }

            // Отображаем информацию с демонстрацией полиморфизма
            SetBkMode(memDC, TRANSPARENT);
            SetTextColor(memDC, RGB(0, 0, 0));

            char info[500];

            // ПОЛИМОРФНОЕ ПОЛУЧЕНИЕ ИНФОРМАЦИИ о текущем мотоцикле
            const char* typeName       = activeDescriptivePtr->getTypeName();        // ПОЛИМОРФНЫЙ ВЫЗОВ!
            const char* description    = activeDescriptivePtr->getDescription();     // ПОЛИМОРФНЫЙ ВЫЗОВ!
            const char* engineSound    = activeSoundPtr->getEngineSound();           // ПОЛИМОРФНЫЙ ВЫЗОВ!
            int         effectStrength = activeDescriptivePtr->getEffectStrength();  // ПОЛИМОРФНЫЙ ВЫЗОВ!

            wsprintfA(info, "TASK 3: POLYMORPHISM | Type: %s | Health: %d%% | Speed: %d | Effect: %d",
                      typeName, activeVehiclePtr->getHealth(), activeVehiclePtr->getSpeed(), effectStrength);
            TextOutA(memDC, 10, 10, info, lstrlenA(info));

            wsprintfA(info, "Description: %s", description);
            TextOutA(memDC, 10, 30, info, lstrlenA(info));

            wsprintfA(info, "Engine Sound: %s", engineSound);
            TextOutA(memDC, 10, 50, info, lstrlenA(info));

            wsprintfA(info, "Controls: WASD/Arrows=Move | R=Respawn All | H=Hide/Show All");
            TextOutA(memDC, 10, 70, info, lstrlenA(info));

            BitBlt(hdcLocal, 0, 0, width, height, memDC, 0, 0, SRCCOPY);

            SelectObject(memDC, oldBitmap);
            DeleteObject(memBitmap);
            DeleteDC(memDC);

            EndPaint(hwnd, &ps);
        } break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// Точка входа в приложение
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
    // Регистрация класса окна
    WNDCLASSEX wc    = {0};
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "task3_polymorphism";
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Ошибка регистрации окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    hwnd = CreateWindowEx(
        0,
        "task3_polymorphism",
        "Задание 3: Использование полиморфизма - Мотоциклы с полиморфными методами",
        WS_OVERLAPPEDWINDOW | WS_MAXIMIZE,
        CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT,
        nullptr, nullptr, hInstance, nullptr);

    if (hwnd == NULL) {
        MessageBox(NULL, "Ошибка создания окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    nShowCmd = SW_MAXIMIZE;
    ShowWindow(hwnd, nShowCmd);
    UpdateWindow(hwnd);

    // Инициализация объектов
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    sportbike = SportBike(width / 2, height / 2);
    cruiser   = Cruiser(width / 2, height / 2);
    dirtbike  = DirtBike(width / 2, height / 2);

    // Полиморфный респавн всех объектов дороги
    PolymorphicRespawnAll();

    // Переинициализация всех полиморфных массивов
    motorcycles[0] = &sportbike;
    motorcycles[1] = &cruiser;
    motorcycles[2] = &dirtbike;

    soundEmitters[0] = &sportbike;
    soundEmitters[1] = &cruiser;
    soundEmitters[2] = &dirtbike;

    motorcycleDescriptors[0] = &sportbike;
    motorcycleDescriptors[1] = &cruiser;
    motorcycleDescriptors[2] = &dirtbike;

    effectGenerators[0] = &sportbike;
    effectGenerators[1] = &cruiser;
    effectGenerators[2] = &dirtbike;

    movableObjects[0] = &sportbike;
    movableObjects[1] = &cruiser;
    movableObjects[2] = &dirtbike;

    displayableObjects[0] = &sportbike;
    displayableObjects[1] = &cruiser;
    displayableObjects[2] = &dirtbike;

    // Случайный выбор начального типа мотоцикла
    std::uniform_int_distribution<> typeRange(0, MOTORCYCLE_COUNT - 1);
    activeMotorcycleType = static_cast<MotorcycleType>(typeRange(mainGenerator));

    // Обновляем все полиморфные указатели на активный мотоцикл
    activeVehiclePtr     = motorcycles[activeMotorcycleType];
    activeMovablePtr     = movableObjects[activeMotorcycleType];
    activeDisplayPtr     = displayableObjects[activeMotorcycleType];
    activeSoundPtr       = soundEmitters[activeMotorcycleType];
    activeDescriptivePtr = motorcycleDescriptors[activeMotorcycleType];
    activeEffectPtr      = effectGenerators[activeMotorcycleType];

    // Полиморфное скрытие всех мотоциклов, затем показ только активного
    for (int i = 0; i < MOTORCYCLE_COUNT; i++) {
        displayableObjects[i]->hide();  // ПОЛИМОРФНЫЙ ВЫЗОВ!
    }

    activeDisplayPtr->show();  // ПОЛИМОРФНЫЙ ВЫЗОВ - показываем выбранный мотоцикл

    InvalidateRect(hwnd, NULL, FALSE);

    // Основной цикл с демонстрацией полиморфизма
    MSG msg;
    while (true) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) {
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        } else {
            CheckKeyboardInput();  // Проверяем ввод с полиморфными вызовами
            Sleep(16);             // ~60 FPS
        }
    }

    return (int)msg.wParam;
}
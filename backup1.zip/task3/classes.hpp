#pragma once
#include <random>

// Структура хитбокса для определения коллизий
struct Hitbox {
    int left;    // Левая граница хитбокса
    int right;   // Правая граница хитбокса
    int top;     // Верхняя граница хитбокса
    int bottom;  // Нижняя граница хитбокса
};

// =====================================================================
// ИНТЕРФЕЙСЫ (чисто виртуальные классы без полей данных)
// =====================================================================

// Интерфейс для объектов, которые могут отображаться на экране
class IDisplayable {
   public:
    virtual ~IDisplayable()  = default;
    virtual void show()      = 0;  // Чисто виртуальный метод для отображения объекта
    virtual void hide()      = 0;  // Чисто виртуальный метод для скрытия объекта
    virtual bool isVisible() = 0;  // Чисто виртуальный метод для проверки видимости
};

// Интерфейс для движущихся объектов
class IMovable {
   public:
    virtual ~IMovable()                     = default;
    virtual void moveUp(int screenHeight)   = 0;
    virtual void moveDown(int screenHeight) = 0;
    virtual void moveLeft(int screenWidth)  = 0;
    virtual void moveRight(int screenWidth) = 0;
    virtual void moveTo(int newX, int newY) = 0;
};

// Интерфейс для объектов, которые могут респавниться
class IRespawnable {
   public:
    virtual ~IRespawnable()                                 = default;
    virtual void respawn(int screenWidth, int screenHeight) = 0;
};

// =====================================================================
// НОВЫЕ ИНТЕРФЕЙСЫ ДЛЯ ДЕМОНСТРАЦИИ ПОЛИМОРФИЗМА (ЗАДАНИЕ 3)
// =====================================================================

// Интерфейс для объектов, которые могут издавать звуки
// Каждый тип мотоцикла будет издавать свой уникальный звук
class ISoundEmitter {
   public:
    virtual ~ISoundEmitter()             = default;
    virtual const char* getEngineSound() = 0;  // Получить звук двигателя (полиморфно)
    virtual const char* getHornSound()   = 0;  // Получить звук сигнала (полиморфно)
};

// Интерфейс для объектов, которые могут предоставлять информацию о себе
// Каждый объект будет описывать себя по-своему
class IDescriptive {
   public:
    virtual ~IDescriptive()                 = default;
    virtual const char* getTypeName()       = 0;  // Получить название типа (полиморфно)
    virtual const char* getDescription()    = 0;  // Получить описание объекта (полиморфно)
    virtual int         getEffectStrength() = 0;  // Получить силу воздействия (полиморфно)
};

// Интерфейс для объектов, которые могут создавать визуальные эффекты при движении
// Разные мотоциклы будут создавать разные эффекты
class IEffectGenerator {
   public:
    virtual ~IEffectGenerator()                   = default;
    virtual void showMovementEffect(int x, int y) = 0;  // Показать эффект движения (полиморфно)
    virtual void hideMovementEffect(int x, int y) = 0;  // Скрыть эффект движения (полиморфно)
};

// =====================================================================
// БАЗОВЫЕ КЛАССЫ С ДАННЫМИ И ОБЩЕЙ ФУНКЦИОНАЛЬНОСТЬЮ
// =====================================================================

// Базовый класс для хранения координат
class Location {
   protected:
    int x;  // Координата X объекта
    int y;  // Координата Y объекта

   public:
    Location(int initX, int initY);
    virtual ~Location();

    int getX();
    int getY();

    void setX(int newX);
    void setY(int newY);
};

// Базовый класс для всех транспортных средств
// ВАЖНО: Теперь также наследует от новых интерфейсов для демонстрации полиморфизма
class Vehicle : public Location, public IDisplayable, public IMovable, public ISoundEmitter, public IDescriptive, public IEffectGenerator {
   protected:
    int    health;   // Здоровье мотоцикла (10-100)
    int    speed;    // Скорость в пикселях за шаг (health/10)
    bool   visible;  // Флаг видимости объекта
    Hitbox hitbox;   // Хитбокс для определения коллизий

   public:
    Vehicle(int initX, int initY, int initHealth);
    virtual ~Vehicle();

    // Геттеры для общих свойств
    int    getHealth();
    int    getSpeed();
    Hitbox getHitbox();

    // Управление здоровьем и скоростью
    void takeDamage(int damage);
    void repair();
    void updateSpeed();
    void updateHitbox();

    // Реализация интерфейса IDisplayable (может быть переопределена в наследниках)
    virtual bool isVisible() override;

    // Реализация интерфейса IMovable (переопределяется в наследниках для эффектов)
    virtual void moveUp(int screenHeight) override;
    virtual void moveDown(int screenHeight) override;
    virtual void moveLeft(int screenWidth) override;
    virtual void moveRight(int screenWidth) override;
    virtual void moveTo(int newX, int newY) override;

    // Базовые методы отображения (ОБЯЗАТЕЛЬНО переопределяются в наследниках - ПОЛИМОРФИЗМ!)
    virtual void show() override = 0;  // Чисто виртуальный - каждый тип рисует себя по-своему
    virtual void hide() override = 0;  // Чисто виртуальный - каждый тип стирает себя по-своему

    // НОВЫЕ ПОЛИМОРФНЫЕ МЕТОДЫ (ЗАДАНИЕ 3):
    // Эти методы будут реализованы по-разному в каждом наследнике

    // Интерфейс ISoundEmitter - каждый мотоцикл издает свои звуки
    virtual const char* getEngineSound() override = 0;  // Чисто виртуальный - полиморфный звук двигателя
    virtual const char* getHornSound() override   = 0;  // Чисто виртуальный - полиморфный звук сигнала

    // Интерфейс IDescriptive - каждый мотоцикл описывает себя по-своему
    virtual const char* getTypeName() override       = 0;  // Чисто виртуальный - полиморфное название
    virtual const char* getDescription() override    = 0;  // Чисто виртуальный - полиморфное описание
    virtual int         getEffectStrength() override = 0;  // Чисто виртуальный - полиморфная сила

    // Интерфейс IEffectGenerator - каждый мотоцикл создает свои эффекты
    virtual void showMovementEffect(int x, int y) override = 0;  // Чисто виртуальный - полиморфный эффект
    virtual void hideMovementEffect(int x, int y) override = 0;  // Чисто виртуальный - полиморфное стирание
};

// Спортивный мотоцикл - быстрый и маневренный
// ДЕМОНСТРИРУЕТ ПОЛИМОРФИЗМ: Все виртуальные методы реализованы по-своему
class SportBike : public Vehicle {
   public:
    SportBike(int initX, int initY);

    // ПОЛИМОРФНЫЕ МЕТОДЫ ОТОБРАЖЕНИЯ - SportBike рисует себя уникально
    virtual void show() override;  // Красный обтекаемый дизайн
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ ЗВУКОВЫЕ ЭФФЕКТЫ - SportBike звучит как гоночный мотоцикл
    virtual const char* getEngineSound() override;  // "VROOOM! High-pitched racing engine!"
    virtual const char* getHornSound() override;    // "Beep-beep! Quick sport horn!"

    // ПОЛИМОРФНОЕ ОПИСАНИЕ - SportBike описывает себя как спортивный
    virtual const char* getTypeName() override;        // "SportBike"
    virtual const char* getDescription() override;     // Описание спортивных характеристик
    virtual int         getEffectStrength() override;  // Высокая интенсивность эффектов

    // ПОЛИМОРФНЫЕ ВИЗУАЛЬНЫЕ ЭФФЕКТЫ - SportBike создает искры скорости
    virtual void showMovementEffect(int x, int y) override;  // Искры и пламя от скорости
    virtual void hideMovementEffect(int x, int y) override;
};

// Круизер - мощный и устойчивый мотоцикл
// ДЕМОНСТРИРУЕТ ПОЛИМОРФИЗМ: Те же интерфейсы, но ДРУГАЯ реализация
class Cruiser : public Vehicle {
   public:
    Cruiser(int initX, int initY);

    // ПОЛИМОРФНЫЕ МЕТОДЫ ОТОБРАЖЕНИЯ - Cruiser рисует себя как массивный мотоцикл
    virtual void show() override;  // Черный массивный дизайн с хромом
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ ЗВУКОВЫЕ ЭФФЕКТЫ - Cruiser звучит мощно и басовито
    virtual const char* getEngineSound() override;  // "GRUMBLE! Deep V-twin rumble!"
    virtual const char* getHornSound() override;    // "HOOOONK! Loud cruiser horn!"

    // ПОЛИМОРФНОЕ ОПИСАНИЕ - Cruiser описывает себя как мощный и комфортный
    virtual const char* getTypeName() override;        // "Cruiser"
    virtual const char* getDescription() override;     // Описание круизерских особенностей
    virtual int         getEffectStrength() override;  // Средняя интенсивность эффектов

    // ПОЛИМОРФНЫЕ ВИЗУАЛЬНЫЕ ЭФФЕКТЫ - Cruiser создает дым от мощного двигателя
    virtual void showMovementEffect(int x, int y) override;  // Дым и следы от мощности
    virtual void hideMovementEffect(int x, int y) override;
};

// Эндуро мотоцикл - проходимый и легкий
// ДЕМОНСТРИРУЕТ ПОЛИМОРФИЗМ: Те же интерфейсы, но ТРЕТЬЯ уникальная реализация
class DirtBike : public Vehicle {
   public:
    DirtBike(int initX, int initY);

    // ПОЛИМОРФНЫЕ МЕТОДЫ ОТОБРАЖЕНИЯ - DirtBike рисует себя как внедорожный
    virtual void show() override;  // Оранжевый дизайн с защитой
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ ЗВУКОВЫЕ ЭФФЕКТЫ - DirtBike звучит резко и отрывисто
    virtual const char* getEngineSound() override;  // "BRRAP! Sharp single-cylinder!"
    virtual const char* getHornSound() override;    // "Pip-pip! Off-road beeper!"

    // ПОЛИМОРФНОЕ ОПИСАНИЕ - DirtBike описывает себя как внедорожный
    virtual const char* getTypeName() override;        // "DirtBike"
    virtual const char* getDescription() override;     // Описание внедорожных способностей
    virtual int         getEffectStrength() override;  // Переменная интенсивность эффектов

    // ПОЛИМОРФНЫЕ ВИЗУАЛЬНЫЕ ЭФФЕКТЫ - DirtBike создает пыль и грязь
    virtual void showMovementEffect(int x, int y) override;  // Пыль и камни от бездорожья
    virtual void hideMovementEffect(int x, int y) override;
};

// Базовый класс для всех объектов на дороге
// ТАКЖЕ ДЕМОНСТРИРУЕТ ПОЛИМОРФИЗМ через новый интерфейс IDescriptive
class RoadObject : public Location, public IDisplayable, public IRespawnable, public IDescriptive {
   protected:
    bool   visible;  // Флаг видимости объекта
    Hitbox hitbox;   // Хитбокс для определения коллизий

   public:
    RoadObject(int initX, int initY);
    virtual ~RoadObject();

    Hitbox getHitbox();
    void   updateHitbox();

    // Реализация интерфейса IDisplayable
    virtual bool isVisible() override;

    // Реализация интерфейса IRespawnable
    virtual void respawn(int screenWidth, int screenHeight) override;

    // Методы отображения остаются чисто виртуальными (ПОЛИМОРФИЗМ!)
    virtual void show() override = 0;  // Каждый объект рисует себя уникально
    virtual void hide() override = 0;  // Каждый объект стирает себя уникально

    // НОВЫЕ ПОЛИМОРФНЫЕ МЕТОДЫ для объектов дороги (ЗАДАНИЕ 3):
    // Интерфейс IDescriptive - каждый объект описывает себя по-своему
    virtual const char* getTypeName() override       = 0;  // Чисто виртуальный - полиморфное название
    virtual const char* getDescription() override    = 0;  // Чисто виртуальный - полиморфное описание
    virtual int         getEffectStrength() override = 0;  // Чисто виртуальный - полиморфная сила воздействия
};

// Камень - наносит случайный урон от 5 до 15
// ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ всех виртуальных методов
class Rock : public RoadObject {
   public:
    Rock(int initX, int initY);

    // ПОЛИМОРФНЫЕ методы отображения
    virtual void show() override;  // Рисует серый неровный камень
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ методы описания
    virtual const char* getTypeName() override;        // "Rock"
    virtual const char* getDescription() override;     // Описание опасности камня
    virtual int         getEffectStrength() override;  // Сила урона камня

    int getDamage();  // Получение случайного урона от камня
};

// Яма - наносит случайный урон от 10 до 25
// ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ с другим поведением
class Pothole : public RoadObject {
   public:
    Pothole(int initX, int initY);

    // ПОЛИМОРФНЫЕ методы отображения
    virtual void show() override;  // Рисует темную овальную яму
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ методы описания
    virtual const char* getTypeName() override;        // "Pothole"
    virtual const char* getDescription() override;     // Описание опасности ямы
    virtual int         getEffectStrength() override;  // Сила урона ямы

    int getDamage();  // Получение случайного урона от ямы
};

// Сервис - полностью восстанавливает здоровье мотоцикла
// ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ с положительным эффектом
class Service : public RoadObject {
   public:
    Service(int initX, int initY);

    // ПОЛИМОРФНЫЕ методы отображения
    virtual void show() override;  // Рисует зеленый сервис с крестом
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ методы описания
    virtual const char* getTypeName() override;        // "Service"
    virtual const char* getDescription() override;     // Описание восстановительного эффекта
    virtual int         getEffectStrength() override;  // Сила восстановления
};

// Трансформер 1 - меняет тип мотоцикла по часовой стрелке
// ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ с трансформационным эффектом
class Transformer1 : public RoadObject {
   public:
    Transformer1(int initX, int initY);

    // ПОЛИМОРФНЫЕ методы отображения
    virtual void show() override;  // Рисует синий трансформер со стрелкой
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ методы описания
    virtual const char* getTypeName() override;        // "Transformer (Clockwise)"
    virtual const char* getDescription() override;     // Описание трансформации по часовой
    virtual int         getEffectStrength() override;  // Сила трансформации
};

// Трансформер 2 - меняет тип мотоцикла против часовой стрелки
// ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ с обратным трансформационным эффектом
class Transformer2 : public RoadObject {
   public:
    Transformer2(int initX, int initY);

    // ПОЛИМОРФНЫЕ методы отображения
    virtual void show() override;  // Рисует фиолетовый трансформер со стрелкой
    virtual void hide() override;

    // ПОЛИМОРФНЫЕ методы описания
    virtual const char* getTypeName() override;        // "Transformer (Counter-Clockwise)"
    virtual const char* getDescription() override;     // Описание трансформации против часовой
    virtual int         getEffectStrength() override;  // Сила трансформации
};
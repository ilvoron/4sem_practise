#include "classes.hpp"
#include <windows.h>
#include <random>

extern HDC bufferDC;  // Буфер, в который рисуют все объекты

static std::random_device randomDevice;
static std::mt19937       generator(randomDevice());

// ============ РЕАЛИЗАЦИЯ КЛАССА Location ============
// Этот класс остается без изменений

Location::Location(int initX, int initY) : x(initX), y(initY) {}
Location::~Location() = default;

int Location::getX() { return x; }
int Location::getY() { return y; }

void Location::setX(int newX) { x = newX; }
void Location::setY(int newY) { y = newY; }

// ============ РЕАЛИЗАЦИЯ КЛАССА Vehicle ============
// Базовая реализация общих методов, полиморфные методы остаются чисто виртуальными

Vehicle::Vehicle(int initX, int initY, int initHealth)
    : Location(initX, initY), health(initHealth), visible(true) {
    if (health < 10) health = 10;
    if (health > 100) health = 100;

    updateSpeed();
    updateHitbox();
}

Vehicle::~Vehicle() = default;

int    Vehicle::getHealth() { return health; }
int    Vehicle::getSpeed() { return speed; }
Hitbox Vehicle::getHitbox() { return hitbox; }

void Vehicle::takeDamage(int damage) {
    health -= damage;
    if (health < 10) health = 10;
    updateSpeed();
}

void Vehicle::repair() {
    health = 100;
    updateSpeed();
}

void Vehicle::updateSpeed() {
    speed = health / 10;
}

void Vehicle::updateHitbox() {
    hitbox.left   = x - 40;
    hitbox.right  = x + 40;
    hitbox.top    = y - 30;
    hitbox.bottom = y + 30;
}

// Реализация интерфейса IDisplayable в базовом классе
bool Vehicle::isVisible() {
    return visible;
}

// Реализация интерфейса IMovable в базовом классе с визуальными эффектами
void Vehicle::moveTo(int newX, int newY) {
    // Показываем эффект движения в старой позиции перед перемещением
    showMovementEffect(x, y);

    hide();
    x = newX;
    y = newY;
    updateHitbox();
    show();

    // Через небольшое время скрываем эффект (в реальной игре это было бы в отдельном потоке)
    Sleep(50);  // Короткая задержка для демонстрации эффекта
    hideMovementEffect(x, y);
}

void Vehicle::moveUp(int screenHeight) {
    int newY = y - speed;
    if (newY >= 30) {
        moveTo(x, newY);
    }
}

void Vehicle::moveDown(int screenHeight) {
    int newY = y + speed;
    if (newY <= screenHeight - 30) {
        moveTo(x, newY);
    }
}

void Vehicle::moveLeft(int screenWidth) {
    int newX = x - speed;
    if (newX >= 40) {
        moveTo(newX, y);
    }
}

void Vehicle::moveRight(int screenWidth) {
    int newX = x + speed;
    if (newX <= screenWidth - 40) {
        moveTo(newX, y);
    }
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА SportBike ============
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: SportBike реализует все виртуальные методы по-своему

SportBike::SportBike(int initX, int initY) : Vehicle(initX, initY, 100) {}

// ПОЛИМОРФНЫЙ метод отображения - SportBike рисует себя как гоночный мотоцикл
void SportBike::show() {
    visible = true;

    // Рисуем спортивный мотоцикл - яркий красный цвет, обтекаемая форма

    // === ОСНОВНОЙ КОРПУС ===
    HPEN   pen      = CreatePen(PS_SOLID, 3, RGB(200, 0, 0));  // Ярко-красный
    HBRUSH brush    = CreateSolidBrush(RGB(220, 0, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Обтекаемый корпус спортбайка
    Ellipse(bufferDC, x - 30, y - 15, x + 30, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === КОЛЕСА ===
    pen      = CreatePen(PS_SOLID, 2, RGB(50, 50, 50));
    brush    = CreateSolidBrush(RGB(80, 80, 80));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Переднее колесо
    Ellipse(bufferDC, x + 15, y - 10, x + 35, y + 10);
    // Заднее колесо
    Ellipse(bufferDC, x - 35, y - 10, x - 15, y + 10);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === РУЛЬ И СИДЕНЬЕ ===
    pen    = CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Руль спортбайка (низкий)
    MoveToEx(bufferDC, x + 20, y - 20, NULL);
    LineTo(bufferDC, x + 30, y - 25);
    MoveToEx(bufferDC, x + 10, y - 20, NULL);
    LineTo(bufferDC, x + 20, y - 25);

    // Спортивное сиденье
    brush    = CreateSolidBrush(RGB(0, 0, 0));
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);
    Rectangle(bufferDC, x - 20, y - 8, x + 5, y - 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === СПОРТИВНЫЕ ДЕТАЛИ ===
    pen    = CreatePen(PS_SOLID, 1, RGB(255, 255, 0));  // Желтые акценты
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Спортивные полосы
    MoveToEx(bufferDC, x - 25, y - 5, NULL);
    LineTo(bufferDC, x + 25, y - 5);
    MoveToEx(bufferDC, x - 25, y + 5, NULL);
    LineTo(bufferDC, x + 25, y + 5);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void SportBike::hide() {
    visible = false;

    // Стираем область мотоцикла белым цветом
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 40, y - 30, x + 40, y + 30);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ звуковые методы SportBike - звучит как гоночный мотоцикл
const char* SportBike::getEngineSound() {
    return "VROOOM! High-pitched racing engine screaming at high RPM!";
}

const char* SportBike::getHornSound() {
    return "Beep-beep! Quick sporty electronic horn!";
}

// ПОЛИМОРФНЫЕ описательные методы SportBike
const char* SportBike::getTypeName() {
    return "SportBike";
}

const char* SportBike::getDescription() {
    return "Lightning-fast racing machine built for speed and agility on the track.";
}

int SportBike::getEffectStrength() {
    return 85;  // Высокая интенсивность эффектов для спортбайка
}

// ПОЛИМОРФНЫЕ визуальные эффекты SportBike - искры скорости
void SportBike::showMovementEffect(int effectX, int effectY) {
    // Рисуем искры и пламя от скорости
    HPEN pen    = CreatePen(PS_SOLID, 1, RGB(255, 150, 0));  // Оранжевые искры
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Несколько искр позади мотоцикла
    for (int i = 0; i < 8; i++) {
        int sparkX = effectX - 50 - (i * 5);
        int sparkY = effectY + (rand() % 20 - 10);

        MoveToEx(bufferDC, sparkX, sparkY, NULL);
        LineTo(bufferDC, sparkX - 8, sparkY + (rand() % 6 - 3));
    }

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void SportBike::hideMovementEffect(int effectX, int effectY) {
    // Стираем эффекты искр
    HPEN pen    = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));  // Белый для стирания
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Стираем область, где были искры
    Rectangle(bufferDC, effectX - 100, effectY - 20, effectX - 40, effectY + 20);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА Cruiser ============
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: Cruiser реализует те же методы, но СОВЕРШЕННО ПО-ДРУГОМУ

Cruiser::Cruiser(int initX, int initY) : Vehicle(initX, initY, 100) {}

// ПОЛИМОРФНЫЙ метод отображения - Cruiser рисует себя как мощный круизер
void Cruiser::show() {
    visible = true;

    // Рисуем круизер - массивный, черный с хромированными деталями

    // === ОСНОВНОЙ КОРПУС ===
    HPEN   pen      = CreatePen(PS_SOLID, 4, RGB(20, 20, 20));
    HBRUSH brush    = CreateSolidBrush(RGB(40, 40, 40));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Массивный корпус круизера
    Rectangle(bufferDC, x - 35, y - 12, x + 35, y + 12);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === КОЛЕСА (большие) ===
    pen      = CreatePen(PS_SOLID, 3, RGB(50, 50, 50));
    brush    = CreateSolidBrush(RGB(80, 80, 80));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Переднее колесо (большое)
    Ellipse(bufferDC, x + 10, y - 15, x + 40, y + 15);
    // Заднее колесо (большое)
    Ellipse(bufferDC, x - 40, y - 15, x - 10, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === РУЛЬ И СИДЕНЬЕ ===
    pen    = CreatePen(PS_SOLID, 3, RGB(200, 200, 200));  // Хром
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Высокий руль круизера
    MoveToEx(bufferDC, x + 15, y - 25, NULL);
    LineTo(bufferDC, x + 15, y - 40);
    MoveToEx(bufferDC, x + 10, y - 40, NULL);
    LineTo(bufferDC, x + 20, y - 40);

    // Широкое сиденье
    brush    = CreateSolidBrush(RGB(100, 50, 0));  // Коричневая кожа
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);
    Rectangle(bufferDC, x - 25, y - 10, x + 10, y - 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === ХРОМИРОВАННЫЕ ДЕТАЛИ ===
    pen    = CreatePen(PS_SOLID, 2, RGB(220, 220, 220));
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Хромированные трубы
    MoveToEx(bufferDC, x - 30, y + 5, NULL);
    LineTo(bufferDC, x - 45, y + 15);
    MoveToEx(bufferDC, x - 30, y + 8, NULL);
    LineTo(bufferDC, x - 45, y + 18);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void Cruiser::hide() {
    visible = false;

    // Стираем область мотоцикла
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 50, y - 45, x + 45, y + 25);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ звуковые методы Cruiser - звучит мощно и басовито
const char* Cruiser::getEngineSound() {
    return "GRUMBLE-GRUMBLE! Deep V-twin rumble shaking the ground!";
}

const char* Cruiser::getHornSound() {
    return "HOOOONK! Loud, deep cruiser horn echoing for miles!";
}

// ПОЛИМОРФНЫЕ описательные методы Cruiser
const char* Cruiser::getTypeName() {
    return "Cruiser";
}

const char* Cruiser::getDescription() {
    return "Powerful touring machine designed for comfort and long-distance rides.";
}

int Cruiser::getEffectStrength() {
    return 65;  // Средняя интенсивность эффектов для круизера
}

// ПОЛИМОРФНЫЕ визуальные эффекты Cruiser - дым от мощного двигателя
void Cruiser::showMovementEffect(int effectX, int effectY) {
    // Рисуем дым от мощного двигателя
    HPEN pen    = CreatePen(PS_SOLID, 2, RGB(120, 120, 120));  // Серый дым
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Несколько клубов дыма
    for (int i = 0; i < 5; i++) {
        int smokeX = effectX - 40 - (i * 8);
        int smokeY = effectY + (i % 2 == 0 ? -5 : 5);

        // Рисуем облако дыма как несколько кругов
        Ellipse(bufferDC, smokeX - 6, smokeY - 4, smokeX + 6, smokeY + 4);
        Ellipse(bufferDC, smokeX - 4, smokeY - 6, smokeX + 4, smokeY + 6);
    }

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void Cruiser::hideMovementEffect(int effectX, int effectY) {
    // Стираем эффекты дыма
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Стираем область, где был дым
    Rectangle(bufferDC, effectX - 80, effectY - 15, effectX - 30, effectY + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА DirtBike ============
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: DirtBike реализует те же методы в ТРЕТЬЕМ уникальном стиле

DirtBike::DirtBike(int initX, int initY) : Vehicle(initX, initY, 100) {}

// ПОЛИМОРФНЫЙ метод отображения - DirtBike рисует себя как внедорожный мотоцикл
void DirtBike::show() {
    visible = true;

    // Рисуем эндуро - оранжевый цвет, высокая подвеска, защита

    // === ОСНОВНОЙ КОРПУС ===
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(255, 140, 0));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 165, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Компактный корпус эндуро
    Ellipse(bufferDC, x - 25, y - 10, x + 25, y + 10);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === КОЛЕСА С ГРЯЗЕВЫМИ ШИНАМИ ===
    pen      = CreatePen(PS_SOLID, 2, RGB(100, 50, 0));
    brush    = CreateSolidBrush(RGB(120, 80, 40));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Переднее колесо
    Ellipse(bufferDC, x + 12, y - 12, x + 35, y + 12);
    // Заднее колесо
    Ellipse(bufferDC, x - 35, y - 12, x - 12, y + 12);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === ВЫСОКАЯ ПОДВЕСКА ===
    pen    = CreatePen(PS_SOLID, 3, RGB(150, 150, 150));
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Передняя вилка
    MoveToEx(bufferDC, x + 23, y - 12, NULL);
    LineTo(bufferDC, x + 23, y - 25);
    // Задний амортизатор
    MoveToEx(bufferDC, x - 23, y - 12, NULL);
    LineTo(bufferDC, x - 23, y - 25);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);

    // === РУЛЬ И СИДЕНЬЕ ===
    pen      = CreatePen(PS_SOLID, 2, RGB(0, 0, 0));
    brush    = CreateSolidBrush(RGB(0, 0, 0));
    oldPen   = (HPEN)SelectObject(bufferDC, pen);
    oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Прямой руль эндуро
    MoveToEx(bufferDC, x + 15, y - 25, NULL);
    LineTo(bufferDC, x + 30, y - 25);
    MoveToEx(bufferDC, x + 22, y - 25, NULL);
    LineTo(bufferDC, x + 22, y - 30);

    // Спортивное сиденье
    Rectangle(bufferDC, x - 20, y - 8, x + 5, y - 5);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);

    // === ЗАЩИТНЫЕ ЭЛЕМЕНТЫ ===
    pen    = CreatePen(PS_SOLID, 1, RGB(50, 50, 50));
    oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Защита двигателя
    MoveToEx(bufferDC, x - 15, y + 8, NULL);
    LineTo(bufferDC, x + 15, y + 8);
    LineTo(bufferDC, x + 10, y + 15);
    LineTo(bufferDC, x - 10, y + 15);
    LineTo(bufferDC, x - 15, y + 8);

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void DirtBike::hide() {
    visible = false;

    // Стираем область мотоцикла
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 40, y - 35, x + 40, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ звуковые методы DirtBike - звучит резко и отрывисто
const char* DirtBike::getEngineSound() {
    return "BRRAP-BRRAP! Sharp single-cylinder engine popping and crackling!";
}

const char* DirtBike::getHornSound() {
    return "Pip-pip! High-pitched off-road warning beeper!";
}

// ПОЛИМОРФНЫЕ описательные методы DirtBike
const char* DirtBike::getTypeName() {
    return "DirtBike";
}

const char* DirtBike::getDescription() {
    return "Rugged off-road machine built to conquer any terrain and jump any obstacle.";
}

int DirtBike::getEffectStrength() {
    // У DirtBike переменная интенсивность в зависимости от "местности"
    std::uniform_int_distribution<> intensity(40, 90);
    return intensity(generator);
}

// ПОЛИМОРФНЫЕ визуальные эффекты DirtBike - пыль и грязь как на бездорожье
void DirtBike::showMovementEffect(int effectX, int effectY) {
    // Рисуем пыль и камни от бездорожья
    HPEN pen    = CreatePen(PS_SOLID, 1, RGB(160, 130, 90));  // Коричневая пыль
    HPEN oldPen = (HPEN)SelectObject(bufferDC, pen);

    // Облако пыли и летящие камни
    for (int i = 0; i < 12; i++) {
        int dustX = effectX - 35 - (rand() % 20);
        int dustY = effectY + (rand() % 30 - 15);

        // Маленькие точки пыли и камней
        SetPixel(bufferDC, dustX, dustY, RGB(160, 130, 90));
        SetPixel(bufferDC, dustX + 1, dustY, RGB(140, 110, 70));
        SetPixel(bufferDC, dustX, dustY + 1, RGB(180, 150, 110));

        // Некоторые более крупные частицы
        if (i % 3 == 0) {
            Rectangle(bufferDC, dustX - 1, dustY - 1, dustX + 2, dustY + 2);
        }
    }

    SelectObject(bufferDC, oldPen);
    DeleteObject(pen);
}

void DirtBike::hideMovementEffect(int effectX, int effectY) {
    // Стираем эффекты пыли и камней
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Стираем широкую область, где была пыль
    Rectangle(bufferDC, effectX - 60, effectY - 20, effectX - 25, effectY + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ============ РЕАЛИЗАЦИЯ КЛАССА RoadObject ============

RoadObject::RoadObject(int initX, int initY) : Location(initX, initY), visible(true) {
    updateHitbox();
}

RoadObject::~RoadObject() = default;

Hitbox RoadObject::getHitbox() { return hitbox; }

void RoadObject::updateHitbox() {
    hitbox.left   = x - 20;
    hitbox.right  = x + 20;
    hitbox.top    = y - 15;
    hitbox.bottom = y + 15;
}

bool RoadObject::isVisible() {
    return visible;
}

void RoadObject::respawn(int screenWidth, int screenHeight) {
    constexpr int padding = 50;

    std::uniform_int_distribution<> distX(padding, screenWidth - padding);
    std::uniform_int_distribution<> distY(padding, screenHeight - padding);

    const int newX = distX(generator);
    const int newY = distY(generator);

    hide();
    x = newX;
    y = newY;
    updateHitbox();
    show();
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА Rock ============
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: Rock описывает себя как опасное препятствие

Rock::Rock(int initX, int initY) : RoadObject(initX, initY) {}

void Rock::show() {
    visible = true;

    // Рисуем камень серого цвета неправильной формы
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(100, 100, 100));
    HBRUSH brush    = CreateSolidBrush(RGB(120, 120, 120));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Неправильная форма камня
    POINT points[6] = {
        {x - 18, y + 10},
        {x - 5, y - 12},
        {x + 8, y - 15},
        {x + 20, y - 5},
        {x + 15, y + 12},
        {x - 10, y + 15}};
    Polygon(bufferDC, points, 6);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

void Rock::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ описательные методы Rock
const char* Rock::getTypeName() {
    return "Rock";
}

const char* Rock::getDescription() {
    return "Sharp granite boulder that can damage wheels and suspension.";
}

int Rock::getEffectStrength() {
    return 25;  // Средняя опасность
}

int Rock::getDamage() {
    std::uniform_int_distribution<> damageRange(5, 15);
    return damageRange(generator);
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА Pothole ============
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: Pothole описывает себя по-другому, чем Rock

Pothole::Pothole(int initX, int initY) : RoadObject(initX, initY) {}

void Pothole::show() {
    visible = true;

    // Рисуем яму темно-коричневого цвета
    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(80, 50, 20));
    HBRUSH brush    = CreateSolidBrush(RGB(60, 40, 20));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Овальная яма
    Ellipse(bufferDC, x - 20, y - 10, x + 20, y + 10);

    // Добавляем тени для глубины
    HBRUSH shadowBrush = CreateSolidBrush(RGB(40, 25, 10));
    SelectObject(bufferDC, shadowBrush);
    Ellipse(bufferDC, x - 15, y - 8, x + 15, y + 8);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(shadowBrush);
}

void Pothole::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 15, x + 25, y + 15);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ описательные методы Pothole - описывает себя иначе, чем Rock
const char* Pothole::getTypeName() {
    return "Pothole";
}

const char* Pothole::getDescription() {
    return "Deep asphalt crater that can cause serious undercarriage damage.";
}

int Pothole::getEffectStrength() {
    return 45;  // Более высокая опасность, чем у камня
}

int Pothole::getDamage() {
    std::uniform_int_distribution<> damageRange(10, 25);
    return damageRange(generator);
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА Service ============
// ДЕМОНСТРАЦИЯ ПОЛИМОРФИЗМА: Service описывает себя как полезный объект

Service::Service(int initX, int initY) : RoadObject(initX, initY) {}

void Service::show() {
    visible = true;

    // Рисуем сервис зеленого цвета с крестом
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(0, 150, 0));
    HBRUSH brush    = CreateSolidBrush(RGB(0, 200, 0));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Основание сервиса
    Rectangle(bufferDC, x - 20, y - 15, x + 20, y + 15);

    // Белый крест
    HPEN   crossPen   = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    HBRUSH crossBrush = CreateSolidBrush(RGB(255, 255, 255));
    SelectObject(bufferDC, crossPen);
    SelectObject(bufferDC, crossBrush);

    // Горизонтальная часть креста
    Rectangle(bufferDC, x - 12, y - 3, x + 12, y + 3);
    // Вертикальная часть креста
    Rectangle(bufferDC, x - 3, y - 12, x + 3, y + 12);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(crossPen);
    DeleteObject(crossBrush);
}

void Service::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ описательные методы Service - описывает себя как восстановительный
const char* Service::getTypeName() {
    return "Service Station";
}

const char* Service::getDescription() {
    return "Professional repair facility that fully restores motorcycle condition.";
}

int Service::getEffectStrength() {
    return 100;  // Максимальная полезность
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА Transformer1 ============

Transformer1::Transformer1(int initX, int initY) : RoadObject(initX, initY) {}

void Transformer1::show() {
    visible = true;

    // Рисуем трансформер синего цвета со стрелкой по часовой стрелке
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(0, 0, 200));
    HBRUSH brush    = CreateSolidBrush(RGB(100, 100, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Основание трансформера (круг)
    Ellipse(bufferDC, x - 20, y - 15, x + 20, y + 15);

    // Стрелка по часовой стрелке
    HPEN arrowPen = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    SelectObject(bufferDC, arrowPen);

    // Кривая стрелка
    MoveToEx(bufferDC, x - 10, y - 8, NULL);
    LineTo(bufferDC, x + 8, y - 8);
    LineTo(bufferDC, x + 8, y + 8);

    // Наконечник стрелки
    MoveToEx(bufferDC, x + 8, y + 8, NULL);
    LineTo(bufferDC, x + 3, y + 3);
    MoveToEx(bufferDC, x + 8, y + 8, NULL);
    LineTo(bufferDC, x + 13, y + 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(arrowPen);
}

void Transformer1::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ описательные методы Transformer1
const char* Transformer1::getTypeName() {
    return "Transformer (Clockwise)";
}

const char* Transformer1::getDescription() {
    return "Mystical device that transforms motorcycles in clockwise sequence.";
}

int Transformer1::getEffectStrength() {
    return 75;  // Магическая сила трансформации
}

// ============ ПОЛИМОРФНАЯ РЕАЛИЗАЦИЯ КЛАССА Transformer2 ============

Transformer2::Transformer2(int initX, int initY) : RoadObject(initX, initY) {}

void Transformer2::show() {
    visible = true;

    // Рисуем трансформер фиолетового цвета со стрелкой против часовой стрелки
    HPEN   pen      = CreatePen(PS_SOLID, 2, RGB(128, 0, 128));
    HBRUSH brush    = CreateSolidBrush(RGB(200, 100, 200));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    // Основание трансформера (круг)
    Ellipse(bufferDC, x - 20, y - 15, x + 20, y + 15);

    // Стрелка против часовой стрелки
    HPEN arrowPen = CreatePen(PS_SOLID, 3, RGB(255, 255, 255));
    SelectObject(bufferDC, arrowPen);

    // Кривая стрелка
    MoveToEx(bufferDC, x + 10, y - 8, NULL);
    LineTo(bufferDC, x - 8, y - 8);
    LineTo(bufferDC, x - 8, y + 8);

    // Наконечник стрелки
    MoveToEx(bufferDC, x - 8, y + 8, NULL);
    LineTo(bufferDC, x - 3, y + 3);
    MoveToEx(bufferDC, x - 8, y + 8, NULL);
    LineTo(bufferDC, x - 13, y + 3);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
    DeleteObject(arrowPen);
}

void Transformer2::hide() {
    visible = false;

    HPEN   pen      = CreatePen(PS_SOLID, 1, RGB(255, 255, 255));
    HBRUSH brush    = CreateSolidBrush(RGB(255, 255, 255));
    HPEN   oldPen   = (HPEN)SelectObject(bufferDC, pen);
    HBRUSH oldBrush = (HBRUSH)SelectObject(bufferDC, brush);

    Rectangle(bufferDC, x - 25, y - 20, x + 25, y + 20);

    SelectObject(bufferDC, oldPen);
    SelectObject(bufferDC, oldBrush);
    DeleteObject(pen);
    DeleteObject(brush);
}

// ПОЛИМОРФНЫЕ описательные методы Transformer2 - отличаются от Transformer1
const char* Transformer2::getTypeName() {
    return "Transformer (Counter-Clockwise)";
}

const char* Transformer2::getDescription() {
    return "Mystical device that transforms motorcycles in reverse sequence.";
}

int Transformer2::getEffectStrength() {
    return 75;  // Та же магическая сила, но в обратном направлении
}
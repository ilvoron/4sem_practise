#pragma once

// Структура хитбокса для определения коллизий
struct Hitbox {
    int left;    // Левая граница хитбокса
    int right;   // Правая граница хитбокса
    int top;     // Верхняя граница хитбокса
    int bottom;  // Нижняя граница хитбокса
};

// Базовый класс для хранения координат
class Location {
   public:
    Location(int initX, int initY);  // Конструктор с инициализацией координат
    virtual ~Location();             // Виртуальный деструктор

    int getX();  // Получение координаты X
    int getY();  // Получение координаты Y

    void setX(int newX);  // Установка новой координаты X
    void setY(int newY);  // Установка новой координаты Y

   private:
    int x;  // Координата X объекта
    int y;  // Координата Y объекта
};

// Базовый класс для всех транспортных средств
class Vehicle : public Location {
   protected:
    int    health;   // Здоровье мотоцикла (10-100)
    int    speed;    // Скорость в пикселях за шаг (health/10)
    bool   visible;  // Флаг видимости объекта
    Hitbox hitbox;   // Хитбокс для определения коллизий

   public:
    Vehicle(int initX, int initY, int initHealth);  // Конструктор с координатами и здоровьем
    virtual ~Vehicle();                             // Виртуальный деструктор

    // Геттеры для общих свойств
    int    getHealth();
    int    getSpeed();
    bool   isVisible();
    Hitbox getHitbox();

    // Управление здоровьем и скоростью
    void takeDamage(int damage);  // Получение урона (не меньше 10 здоровья)
    void repair();                // Полное восстановление здоровья
    void updateSpeed();           // Обновление скорости на основе здоровья
    void updateHitbox();          // Обновление хитбокса на основе текущих координат

    // Базовые методы отображения и перемещения (будут переопределены в наследниках)
    virtual void show();                      // Отображение транспорта на экране
    virtual void hide();                      // Скрытие транспорта с экрана
    virtual void moveTo(int newX, int newY);  // Перемещение в новую позицию

    // Методы движения с учетом скорости и границ экрана
    void moveUp(int screenHeight);    // Движение вверх
    void moveDown(int screenHeight);  // Движение вниз
    void moveLeft(int screenWidth);   // Движение влево
    void moveRight(int screenWidth);  // Движение вправо
};

// Спортивный мотоцикл - быстрый и маневренный
class SportBike : public Vehicle {
   public:
    SportBike(int initX, int initY);  // Конструктор

    // Переопределенные методы отрисовки для уникального внешнего вида
    virtual void show();  // Отображение спортбайка на экране
    virtual void hide();  // Скрытие спортбайка с экрана
};

// Круизер - мощный и устойчивый мотоцикл
class Cruiser : public Vehicle {
   public:
    Cruiser(int initX, int initY);  // Конструктор

    // Переопределенные методы отрисовки для уникального внешнего вида
    virtual void show();  // Отображение круизера на экране
    virtual void hide();  // Скрытие круизера с экрана
};

// Эндуро мотоцикл - проходимый и легкий
class DirtBike : public Vehicle {
   public:
    DirtBike(int initX, int initY);  // Конструктор

    // Переопределенные методы отрисовки для уникального внешнего вида
    virtual void show();  // Отображение эндуро на экране
    virtual void hide();  // Скрытие эндуро с экрана
};

// Базовый класс для всех объектов на дороге
class RoadObject : public Location {
   protected:
    bool   visible;  // Флаг видимости объекта
    Hitbox hitbox;   // Хитбокс для определения коллизий

   public:
    RoadObject(int initX, int initY);  // Конструктор
    virtual ~RoadObject();             // Виртуальный деструктор

    bool   isVisible();     // Проверка видимости
    Hitbox getHitbox();     // Получение хитбокса
    void   updateHitbox();  // Обновление хитбокса

    // Методы отображения (будут переопределены в наследниках)
    virtual void show() = 0;  // Чисто виртуальный метод отображения
    virtual void hide() = 0;  // Чисто виртуальный метод скрытия

    // Респавн в случайном месте на экране
    void respawn(int screenWidth, int screenHeight);
};

// Камень - наносит случайный урон от 5 до 15
class Rock : public RoadObject {
   public:
    Rock(int initX, int initY);  // Конструктор

    virtual void show();  // Отображение камня
    virtual void hide();  // Скрытие камня

    int getDamage();  // Получение случайного урона от камня
};

// Яма - наносит случайный урон от 10 до 25
class Pothole : public RoadObject {
   public:
    Pothole(int initX, int initY);  // Конструктор

    virtual void show();  // Отображение ямы
    virtual void hide();  // Скрытие ямы

    int getDamage();  // Получение случайного урона от ямы
};

// Сервис - полностью восстанавливает здоровье мотоцикла
class Service : public RoadObject {
   public:
    Service(int initX, int initY);  // Конструктор

    virtual void show();  // Отображение сервиса
    virtual void hide();  // Скрытие сервиса
};

// Трансформер 1 - меняет тип мотоцикла по часовой стрелке
class Transformer1 : public RoadObject {
   public:
    Transformer1(int initX, int initY);  // Конструктор

    virtual void show();  // Отображение трансформера
    virtual void hide();  // Скрытие трансформера
};

// Трансформер 2 - меняет тип мотоцикла против часовой стрелки
class Transformer2 : public RoadObject {
   public:
    Transformer2(int initX, int initY);  // Конструктор

    virtual void show();  // Отображение трансформера
    virtual void hide();  // Скрытие трансформера
};
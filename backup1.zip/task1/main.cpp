/************************************************************
 *                  ЗАДАНИЕ 1: НАСЛЕДОВАНИЕ КЛАССОВ        *
 *----------------------------------------------------------*
 * Project Type  : Win64 Console Application                *
 * Project Name  : task1_inheritance                        *
 * File Name     : main.cpp                                 *
 * Language      : CPP, MSVC 2022                           *
 * Programmer    : Student                                  *
 * Created       : 30.06.2025                               *
 * Last Revision : 30.06.2025                               *
 * Comment(s)    : Демонстрация наследования классов        *
 *                 Базовый класс Vehicle и наследники       *
 *                 SportBike, Cruiser, DirtBike             *
 ************************************************************/

#include <windows.h>
#include <random>
#include "classes.hpp"

#define KEY_DOWN(vk_code) ((GetAsyncKeyState(vk_code) & 0x8000) ? 1 : 0)
#define _UNICODE

HWND hwnd;      // Глобальный дескриптор окна
HDC  bufferDC;  // Глобальный HDC, используемый при отрисовке

// Генератор случайных чисел для main.cpp (отдельный от classes.cpp)
static std::random_device mainRandomDevice;
static std::mt19937       mainGenerator(mainRandomDevice());

// Индексы типов мотоциклов для матриц переходов
enum MotorcycleType {
    SPORTBIKE = 0,
    CRUISER   = 1,
    DIRTBIKE  = 2,
    MOTORCYCLE_COUNT
};

// Глобальные объекты мотоциклов (создаются в одной позиции)
SportBike sportbike(400, 300);
Cruiser   cruiser(400, 300);
DirtBike  dirtbike(400, 300);

// Глобальные объекты на дороге
Rock         rock(150, 150);
Pothole      pothole(650, 450);
Service      service(400, 150);
Transformer1 transformer1(200, 450);  // Меняет тип по часовой стрелке
Transformer2 transformer2(600, 150);  // Меняет тип против часовой стрелки

// Массив указателей на все мотоциклы для прямого доступа (полиморфизм)
Vehicle* motorcycles[MOTORCYCLE_COUNT] = {&sportbike, &cruiser, &dirtbike};

// Матрицы переходов для трансформеров
// [текущий индекс типа] = новый индекс типа
const MotorcycleType clockwiseTransitions[MOTORCYCLE_COUNT] = {
    CRUISER,   // SportBike -> Cruiser
    DIRTBIKE,  // Cruiser -> DirtBike
    SPORTBIKE  // DirtBike -> SportBike
};

const MotorcycleType counterClockwiseTransitions[MOTORCYCLE_COUNT] = {
    DIRTBIKE,   // SportBike -> DirtBike
    SPORTBIKE,  // Cruiser -> SportBike
    CRUISER     // DirtBike -> Cruiser
};

// Текущий тип активного мотоцикла
MotorcycleType activeMotorcycleType = SPORTBIKE;

// Указатель на текущий активный мотоцикл (демонстрация полиморфизма)
Vehicle* activeMotorcyclePtr = motorcycles[activeMotorcycleType];

// Глобальная функция проверки коллизий между мотоциклом и объектом на дороге
bool isCollision(Vehicle* motorcycle, RoadObject* roadObj) {
    if (!motorcycle || !roadObj) return false;
    if (!motorcycle->isVisible() || !roadObj->isVisible()) return false;

    Hitbox motorcycleHitbox = motorcycle->getHitbox();
    Hitbox objectHitbox     = roadObj->getHitbox();

    // Проверяем пересечение хитбоксов
    return (objectHitbox.left <= motorcycleHitbox.right &&
            objectHitbox.right >= motorcycleHitbox.left &&
            objectHitbox.top <= motorcycleHitbox.bottom &&
            objectHitbox.bottom >= motorcycleHitbox.top);
}

// Функция для изменения активного мотоцикла (демонстрация наследования)
void ChangeActiveMotorcycle(MotorcycleType newMotorcycleType) {
    // Получаем текущие координаты через полиморфный указатель
    int x      = activeMotorcyclePtr->getX();
    int y      = activeMotorcyclePtr->getY();
    int health = activeMotorcyclePtr->getHealth();

    // Скрываем текущий мотоцикл
    activeMotorcyclePtr->hide();

    // Устанавливаем новый тип мотоцикла
    activeMotorcycleType = newMotorcycleType;

    // Обновляем указатель на активный мотоцикл (прямой доступ через массив)
    activeMotorcyclePtr = motorcycles[activeMotorcycleType];

    // Устанавливаем здоровье нового мотоцикла равным предыдущему
    while (activeMotorcyclePtr->getHealth() > health) {
        activeMotorcyclePtr->takeDamage(1);
    }
    if (activeMotorcyclePtr->getHealth() < health) {
        // Если нужно увеличить здоровье, ремонтируем и снова уменьшаем
        activeMotorcyclePtr->repair();
        while (activeMotorcyclePtr->getHealth() > health) {
            activeMotorcyclePtr->takeDamage(1);
        }
    }

    // Перемещаем и показываем новый активный мотоцикл
    activeMotorcyclePtr->moveTo(x, y);
    activeMotorcyclePtr->show();
}

// Функция проверки всех коллизий
void CheckCollisions() {
    bool collision = false;

    // Получаем размеры клиентской области
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Проверяем коллизию с камнем (наносит урон 5-15)
    if (isCollision(activeMotorcyclePtr, &rock)) {
        collision  = true;
        int damage = rock.getDamage();
        activeMotorcyclePtr->takeDamage(damage);
        rock.respawn(width, height);  // Респавним камень
    }

    // Проверяем коллизию с ямой (наносит урон 10-25)
    if (isCollision(activeMotorcyclePtr, &pothole)) {
        collision  = true;
        int damage = pothole.getDamage();
        activeMotorcyclePtr->takeDamage(damage);
        pothole.respawn(width, height);  // Респавним яму
    }

    // Проверяем коллизию с сервисом (полное восстановление)
    if (isCollision(activeMotorcyclePtr, &service)) {
        collision = true;
        activeMotorcyclePtr->repair();   // Полное восстановление здоровья
        service.respawn(width, height);  // Респавним сервис
    }

    // Проверяем коллизию с трансформером 1 (по часовой стрелке)
    if (isCollision(activeMotorcyclePtr, &transformer1)) {
        collision = true;

        // Используем матрицу переходов по часовой стрелке
        MotorcycleType newType = clockwiseTransitions[activeMotorcycleType];
        ChangeActiveMotorcycle(newType);

        transformer1.respawn(width, height);  // Респавним трансформер
    }

    // Проверяем коллизию с трансформером 2 (против часовой стрелки)
    if (isCollision(activeMotorcyclePtr, &transformer2)) {
        collision = true;

        // Используем матрицу переходов против часовой стрелки
        MotorcycleType newType = counterClockwiseTransitions[activeMotorcycleType];
        ChangeActiveMotorcycle(newType);

        transformer2.respawn(width, height);  // Респавним трансформер
    }

    if (collision) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Функция обработки ввода с клавиатуры (управление мотоциклом)
void CheckKeyboardInput() {
    bool needRedraw = false;

    // Получаем размеры клиентской области
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Движение активного мотоцикла через полиморфный указатель
    // Скорость зависит от здоровья мотоцикла (демонстрация наследования свойств)

    if (KEY_DOWN('W') || KEY_DOWN('w') || KEY_DOWN(VK_UP)) {
        activeMotorcyclePtr->moveUp(height);
        needRedraw = true;
    }
    if (KEY_DOWN('S') || KEY_DOWN('s') || KEY_DOWN(VK_DOWN)) {
        activeMotorcyclePtr->moveDown(height);
        needRedraw = true;
    }
    if (KEY_DOWN('A') || KEY_DOWN('a') || KEY_DOWN(VK_LEFT)) {
        activeMotorcyclePtr->moveLeft(width);
        needRedraw = true;
    }
    if (KEY_DOWN('D') || KEY_DOWN('d') || KEY_DOWN(VK_RIGHT)) {
        activeMotorcyclePtr->moveRight(width);
        needRedraw = true;
    }

    // Диагональное движение
    if ((KEY_DOWN('W') || KEY_DOWN('w') || KEY_DOWN(VK_UP)) &&
        (KEY_DOWN('A') || KEY_DOWN('a') || KEY_DOWN(VK_LEFT))) {
        // Уже обработано выше, но можно добавить дополнительную логику
    }

    CheckCollisions();  // Проверка коллизий после каждого движения
    if (needRedraw) {
        InvalidateRect(hwnd, NULL, FALSE);
    }
}

// Обработчик сообщений окна
LRESULT CALLBACK WndProc(HWND hwnd, const UINT msg, const WPARAM wParam, const LPARAM lParam) {
    PAINTSTRUCT ps;

    switch (msg) {
        case WM_PAINT: {
            HDC hdcLocal = BeginPaint(hwnd, &ps);

            // Получаем размеры клиентской области
            RECT rect;
            GetClientRect(hwnd, &rect);
            const int width  = rect.right - rect.left;
            const int height = rect.bottom - rect.top;

            // Создаем совместимый DC и битмап в памяти для двойной буферизации
            HDC     memDC     = CreateCompatibleDC(hdcLocal);
            HBITMAP memBitmap = CreateCompatibleBitmap(hdcLocal, width, height);
            HBITMAP oldBitmap = (HBITMAP)SelectObject(memDC, memBitmap);

            // Заполняем фон светло-серым цветом (дорога)
            HBRUSH bgBrush  = CreateSolidBrush(RGB(200, 200, 200));  // Серая дорога
            HBRUSH oldBrush = (HBRUSH)SelectObject(memDC, bgBrush);
            FillRect(memDC, &rect, bgBrush);
            SelectObject(memDC, oldBrush);
            DeleteObject(bgBrush);

            bufferDC = memDC;  // Устанавливаем глобальный буфер HDC

            // Отрисовываем активный мотоцикл через полиморфный указатель
            // (демонстрация полиморфизма - один интерфейс для разных типов)
            activeMotorcyclePtr->show();

            // Отрисовываем все объекты на дороге
            rock.show();
            pothole.show();
            service.show();
            transformer1.show();
            transformer2.show();

            // Отображаем информацию о мотоцикле в углу экрана
            SetBkMode(memDC, TRANSPARENT);
            SetTextColor(memDC, RGB(0, 0, 0));

            char        info[200];
            const char* typeName = "";
            switch (activeMotorcycleType) {
                case SPORTBIKE: typeName = "SportBike"; break;
                case CRUISER: typeName = "Cruiser"; break;
                case DIRTBIKE: typeName = "DirtBike"; break;
            }

            wsprintfA(info, "Motorcycle: %s | Health: %d%% | Speed: %d px/step",
                      typeName, activeMotorcyclePtr->getHealth(), activeMotorcyclePtr->getSpeed());
            TextOutA(memDC, 10, 10, info, lstrlenA(info));

            // Копируем результат из памяти на экран
            BitBlt(hdcLocal, 0, 0, width, height, memDC, 0, 0, SRCCOPY);

            SelectObject(memDC, oldBitmap);
            DeleteObject(memBitmap);
            DeleteDC(memDC);

            EndPaint(hwnd, &ps);
        } break;

        case WM_DESTROY:
            PostQuitMessage(0);
            break;

        default:
            return DefWindowProc(hwnd, msg, wParam, lParam);
    }
    return 0;
}

// Точка входа в приложение
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd) {
    // Регистрация класса окна
    WNDCLASSEX wc    = {0};
    wc.cbSize        = sizeof(WNDCLASSEX);
    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = WndProc;
    wc.hInstance     = hInstance;
    wc.hIcon         = LoadIcon(NULL, IDI_APPLICATION);
    wc.hCursor       = LoadCursor(NULL, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszClassName = "task1_inheritance";
    wc.hIconSm       = LoadIcon(NULL, IDI_APPLICATION);

    if (!RegisterClassEx(&wc)) {
        MessageBox(NULL, "Ошибка регистрации окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    // Создание окна
    hwnd = CreateWindowEx(
        0,
        "task1_inheritance",
        "Задание 1: Наследование классов - Мотоциклы",
        WS_OVERLAPPEDWINDOW | WS_MAXIMIZE,
        CW_USEDEFAULT, CW_USEDEFAULT,
        CW_USEDEFAULT, CW_USEDEFAULT,
        nullptr, nullptr, hInstance, nullptr);

    if (hwnd == NULL) {
        MessageBox(NULL, "Ошибка создания окна!", "Ошибка", MB_ICONERROR | MB_OK);
        return 1;
    }

    nShowCmd = SW_MAXIMIZE;
    ShowWindow(hwnd, nShowCmd);
    UpdateWindow(hwnd);

    // Получаем размеры клиентской области для инициализации объектов
    RECT rect;
    GetClientRect(hwnd, &rect);
    const int width  = rect.right - rect.left;
    const int height = rect.bottom - rect.top;

    // Инициализация мотоциклов в центре экрана
    // Все мотоциклы создаются в одной позиции, но показан только один
    sportbike = SportBike(width / 2, height / 2);
    cruiser   = Cruiser(width / 2, height / 2);
    dirtbike  = DirtBike(width / 2, height / 2);

    // Инициализация объектов на дороге в случайных позициях
    rock.respawn(width, height);
    pothole.respawn(width, height);
    service.respawn(width, height);
    transformer1.respawn(width, height);
    transformer2.respawn(width, height);

    // Переинициализация массива указателей после пересоздания объектов
    motorcycles[0] = &sportbike;
    motorcycles[1] = &cruiser;
    motorcycles[2] = &dirtbike;

    // Случайный выбор начального типа мотоцикла
    std::uniform_int_distribution<> typeRange(0, MOTORCYCLE_COUNT - 1);
    activeMotorcycleType = static_cast<MotorcycleType>(typeRange(mainGenerator));
    activeMotorcyclePtr  = motorcycles[activeMotorcycleType];

    // Изначально скрываем все мотоциклы, затем показываем только активный
    sportbike.hide();
    cruiser.hide();
    dirtbike.hide();

    activeMotorcyclePtr->show();  // Показываем случайно выбранный мотоцикл

    InvalidateRect(hwnd, NULL, FALSE);

    // Основной цикл обработки сообщений
    MSG msg;
    while (true) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            if (msg.message == WM_QUIT) {
                break;
            }
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        } else {
            CheckKeyboardInput();  // Проверяем нажатия клавиш
            Sleep(16);             // ~60 FPS
        }
    }

    return (int)msg.wParam;
}